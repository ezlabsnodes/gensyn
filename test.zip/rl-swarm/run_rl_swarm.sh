#!/bin/bash
set -euo pipefail

# ============================
# General & Paths
# ============================
ROOT=$PWD
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ============================
# Versions
# ============================
GENRL_TAG="0.1.8"

# ============================
# Environment
# ============================
export IDENTITY_PATH
export GENSYN_RESET_CONFIG
export CONNECT_TO_TESTNET=true
export ORG_ID
export HF_HUB_DOWNLOAD_TIMEOUT=120  # 2 minutes
export SWARM_CONTRACT="0xFaD7C5e93f28257429569B854151A1B8DCD404c2"
export PRG_CONTRACT="0x51D4db531ae706a6eC732458825465058fA23a35"

# Non-interactive defaults
export HUGGINGFACE_ACCESS_TOKEN="None"                 # auto choose "N"
export MODEL_NAME="Gensyn/Qwen2.5-0.5B-Instruct"       # default model (override with env if needed)
export PRG_GAME=true                                    # default join PRG game

# Path to RSA private key (auto-created by app if missing)
DEFAULT_IDENTITY_PATH="$ROOT"/swarm.pem
IDENTITY_PATH=${IDENTITY_PATH:-$DEFAULT_IDENTITY_PATH}

DOCKER=${DOCKER:-""}
GENSYN_RESET_CONFIG=${GENSYN_RESET_CONFIG:-""}
CPU_ONLY=${CPU_ONLY:-""}
ORG_ID=${ORG_ID:-""}

# ============================
# Console colors
# ============================
GREEN_TEXT="\033[32m"; BLUE_TEXT="\033[34m"; RED_TEXT="\033[31m"; RESET_TEXT="\033[0m"
echo_green(){ echo -e "$GREEN_TEXT$1$RESET_TEXT"; }
echo_blue(){ echo -e "$BLUE_TEXT$1$RESET_TEXT"; }
echo_red(){ echo -e "$RED_TEXT$1$RESET_TEXT"; }

# ============================
# System tuning
# ============================
ulimit -n 65535 || true

# ============================
# Auto-login helpers & state
# ============================
SOURCE_EZLABS_DIR="/root/ezlabs/"
DEST_MODAL_DATA_DIR="$ROOT/modal-login/temp-data/"
DEST_ROOT_DIR="$ROOT/"

# PIDs tracked for cleanup
SERVER_PID=""     # yarn start (modal-login)
PYTHON_ACTUAL_PID=""
TEE_PID=""
TUNNEL_PID=""

# ============================
# Cleanup & error traps
# ============================
cleanup() {
  echo_green ">> Shutting down trainer & cleaning up..."
  cd "$ROOT" || true

  # Kill background helpers quickly & quietly
  pkill -f "DHT-" 2>/dev/null || true
  pkill -f "hivemind" 2>/dev/null || true
  pkill -f "lt --port" 2>/dev/null || true

  if [ -n "${SERVER_PID:-}" ] && kill -0 "$SERVER_PID" 2>/dev/null; then
    echo ">> Stopping modal-login server (PID: $SERVER_PID)..."
    kill -9 "$SERVER_PID" 2>/dev/null || true
    wait "$SERVER_PID" 2>/dev/null || true
  fi
  if [ -n "${PYTHON_ACTUAL_PID:-}" ] && kill -0 "$PYTHON_ACTUAL_PID" 2>/dev/null; then
    echo ">> Stopping Python process (PID: $PYTHON_ACTUAL_PID)..."
    kill -9 "$PYTHON_ACTUAL_PID" 2>/dev/null || true
    wait "$PYTHON_ACTUAL_PID" 2>/dev/null || true
  fi
  if [ -n "${TEE_PID:-}" ] && kill -0 "$TEE_PID" 2>/dev/null; then
    echo ">> Stopping tee (PID: $TEE_PID)..."
    kill -9 "$TEE_PID" 2>/dev/null || true
    wait "$TEE_PID" 2>/dev/null || true
  fi
  if [ -n "${TUNNEL_PID:-}" ] && kill -0 "$TUNNEL_PID" 2>/dev/null; then
    echo ">> Stopping localtunnel (PID: $TUNNEL_PID)..."
    kill -9 "$TUNNEL_PID" 2>/dev/null || true
    wait "$TUNNEL_PID" 2>/dev/null || true
  fi

  # Remove modal credentials JSONs (keep swarm.pem)
  rm -f "$ROOT_DIR/modal-login/temp-data/"*.json 2>/dev/null || true

  echo_green ">> Cleanup complete."
}

errnotify(){ echo_red ">> A critical error occurred. See $ROOT/logs for details."; }

trap cleanup EXIT
trap errnotify ERR

# ============================
# Banner
# ============================
cat << 'EOF'
\033[38;5;224m
    ██████  ██            ███████ ██     ██  █████  ██████  ███    ███
    ██   ██ ██            ██      ██     ██ ██   ██ ██   ██ ████  ████
    ██████  ██      █████ ███████ ██  █  ██ ███████ ██████  ██ ████ ██
    ██   ██ ██                 ██ ██ ███ ██ ██   ██ ██   ██ ██  ██  ██
    ██   ██ ███████       ███████  ███ ███  ██   ██ ██   ██ ██      ██

    From Gensyn
\033[0m
EOF

# ============================
# Docker permissions (if any)
# ============================
if [ -n "$DOCKER" ]; then
  volumes=(
    /home/gensyn/rl_swarm/modal-login/temp-data
    /home/gensyn/rl_swarm/keys
    /home/gensyn/rl_swarm/configs
    /home/gensyn/rl_swarm/logs
  )
  for volume in "${volumes[@]}"; do
    sudo chown -R 1001:1001 "$volume" || true
  done
fi

# ============================
# Logs directory
# ============================
mkdir -p "$ROOT/logs"

# ============================
# Localtunnel helpers - FIXED
# ============================
install_localtunnel(){
  if command -v lt >/dev/null 2>&1; then
    echo_green ">> localtunnel already installed."
    return 0
  fi
  echo_green ">> Installing localtunnel..."
  if ! npm install -g localtunnel >/dev/null 2>&1; then
    echo_red ">> Failed to install localtunnel"
    return 1
  fi
  echo_green ">> localtunnel installed."
  return 0
}

start_localtunnel(){
  local PORT=3000
  echo_green ">> Starting localtunnel on port $PORT..."
  lt --port "$PORT" > "$ROOT/localtunnel_output.log" 2>&1 &
  TUNNEL_PID=$!
  
  # Wait for tunnel to establish
  sleep 8
  
  local URL=""
  if [ -f "$ROOT/localtunnel_output.log" ]; then
    URL=$(grep -o "https://[^ ]*" "$ROOT/localtunnel_output.log" | head -n1 || true)
  fi
  
  if [ -n "${URL:-}" ]; then
    echo_green ">> Public URL: ${URL}"
    # Try to get password (optional, don't fail if it doesn't work)
    local PASS
    PASS=$(curl -s --connect-timeout 5 "https://loca.lt/mytunnelpassword" || echo "unknown")
    if [ "$PASS" != "unknown" ]; then
      echo_green ">> Access password: ${PASS}"
    fi
    return 0
  else
    echo_red ">> Failed to get localtunnel URL. Check $ROOT/localtunnel_output.log for details."
    if [ -n "$TUNNEL_PID" ]; then
      kill "$TUNNEL_PID" 2>/dev/null || true
    fi
    return 1
  fi
}

# ============================
# Wait for API key activation - FIXED
# ============================
wait_for_api_key_activation() {
  local org_id=$1
  local max_attempts=60
  local attempt=0
  
  echo "Waiting for API key to become activated..."
  
  while [ $attempt -lt $max_attempts ]; do
    STATUS=$(curl -s --connect-timeout 10 "http://localhost:3000/api/get-api-key-status?orgId=$org_id" || echo "error")
    
    if [[ "$STATUS" == "activated" ]]; then
      echo_green ">> API key is activated! Proceeding..."
      return 0
    elif [[ "$STATUS" == "error" ]]; then
      echo ">> Server not responding, attempt $((attempt + 1))/$max_attempts..."
    else
      echo ">> API key status: $STATUS, attempt $((attempt + 1))/$max_attempts..."
    fi
    
    sleep 5
    attempt=$((attempt + 1))
  done
  
  echo_red ">> ERROR: API key activation timeout after $max_attempts attempts"
  return 1
}

# ============================
# Extract ORG_ID - FIXED
# ============================
extract_org_id() {
  local user_data_file="$ROOT/modal-login/temp-data/userData.json"
  
  if [ ! -f "$user_data_file" ]; then
    echo_red "ERROR: userData.json not found at $user_data_file"
    return 1
  fi
  
  # More robust JSON parsing
  if command -v jq >/dev/null 2>&1; then
    ORG_ID=$(jq -r '.orgId // empty' "$user_data_file" 2>/dev/null)
  else
    # Fallback to awk if jq not available
    ORG_ID=$(awk -F'"' '/"orgId":/ {print $4}' "$user_data_file" | head -1)
  fi
  
  if [ -z "$ORG_ID" ]; then
    echo_red "ERROR: Could not extract ORG_ID from userData.json"
    return 1
  fi
  
  echo ">> Your ORG_ID is set to: $ORG_ID"
  export ORG_ID
  return 0
}

# ============================
# Setup Node.js and Yarn - FIXED
# ============================
setup_node_environment() {
  # Install Node.js if not present
  if ! command -v node >/dev/null 2>&1; then
    echo "Node.js not found. Installing NVM and latest Node.js..."
    export NVM_DIR="$HOME/.nvm"
    if [ ! -d "$NVM_DIR" ]; then
      curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
    fi
    # Source nvm
    [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"
    [ -s "$NVM_DIR/bash_completion" ] && . "$NVM_DIR/bash_completion"
    nvm install --lts
    nvm use --lts
  else
    echo ">> Node.js is already installed: $(node -v)"
  fi

  # Install Yarn if not present
  if ! command -v yarn >/dev/null 2>&1; then
    echo ">> Installing Yarn..."
    if command -v npm >/dev/null 2>&1; then
      npm install -g yarn
    else
      echo_red ">> ERROR: npm not available to install yarn"
      return 1
    fi
  fi
  echo ">> Yarn version: $(yarn --version)"
}

# ============================
# Patch environment file - FIXED
# ============================
patch_env_file() {
  local env_file="$ROOT/modal-login/.env"
  
  if [ ! -f "$env_file" ]; then
    echo_red ">> ERROR: .env file not found at $env_file"
    return 1
  fi
  
  echo ">> Patching .env file with contract addresses..."
  
  # Backup original file
  cp "$env_file" "$env_file.backup" 2>/dev/null || true
  
  # Use sed compatible with both Linux and macOS
  if [[ "$OSTYPE" == "darwin"* ]]; then
    sed -i '' "s|SWARM_CONTRACT_ADDRESS=.*|SWARM_CONTRACT_ADDRESS=$SWARM_CONTRACT|" "$env_file"
    sed -i '' "s|PRG_CONTRACT_ADDRESS=.*|PRG_CONTRACT_ADDRESS=$PRG_CONTRACT|" "$env_file"
  else
    sed -i "s|SWARM_CONTRACT_ADDRESS=.*|SWARM_CONTRACT_ADDRESS=$SWARM_CONTRACT|" "$env_file"
    sed -i "s|PRG_CONTRACT_ADDRESS=.*|PRG_CONTRACT_ADDRESS=$PRG_CONTRACT|" "$env_file"
  fi
  
  echo_green ">> .env file patched successfully"
}

# ============================
# Start modal login server - FIXED
# ============================
start_modal_server() {
  cd "$ROOT/modal-login"
  
  # Build if not in Docker
  if [ -z "$DOCKER" ]; then
    echo ">> Installing dependencies..."
    if ! yarn install --immutable > "$ROOT/logs/yarn_install.log" 2>&1; then
      echo_red ">> Yarn install failed, check $ROOT/logs/yarn_install.log"
      return 1
    fi
    
    echo ">> Building server..."
    if ! yarn build > "$ROOT/logs/yarn_build.log" 2>&1; then
      echo_red ">> Build failed, check $ROOT/logs/yarn_build.log"
      return 1
    fi
  fi
  
  echo ">> Starting modal login server..."
  yarn start >> "$ROOT/logs/yarn_server.log" 2>&1 &
  SERVER_PID=$!
  
  # Wait for server to start
  sleep 10
  
  # Check if server is running
  if ! kill -0 "$SERVER_PID" 2>/dev/null; then
    echo_red ">> Server failed to start"
    return 1
  fi
  
  echo_green ">> Modal login server started (PID: $SERVER_PID)"
  cd "$ROOT"
  return 0
}

# ============================
# Copy credentials if available - FIXED
# ============================
copy_existing_credentials() {
  if [ -f "$SOURCE_EZLABS_DIR/userData.json" ] && [ -f "$SOURCE_EZLABS_DIR/userApiKey.json" ]; then
    echo_green ">> Found existing credentials, copying..."
    mkdir -p "$DEST_MODAL_DATA_DIR"
    cp -f "$SOURCE_EZLABS_DIR/userData.json" "$DEST_MODAL_DATA_DIR/"
    cp -f "$SOURCE_EZLABS_DIR/userApiKey.json" "$DEST_MODAL_DATA_DIR/"
    
    if [ -f "$SOURCE_EZLABS_DIR/swarm.pem" ] && [ ! -f "$DEST_ROOT_DIR/swarm.pem" ]; then
      echo ">> Copying swarm.pem to project root..."
      cp -f "$SOURCE_EZLABS_DIR/swarm.pem" "$DEST_ROOT_DIR/" || true
    fi
    return 0
  elif [ -f "$ROOT/modal-login/temp-data/userData.json" ] && [ -f "$ROOT/modal-login/temp-data/userApiKey.json" ]; then
    echo_green ">> Credentials already present in destination"
    return 0
  else
    return 1
  fi
}

# ============================
# CONNECT_TO_TESTNET flow (with autologin & localtunnel) - FIXED
# ============================
if [ "$CONNECT_TO_TESTNET" = "true" ]; then
  echo ">> Starting testnet connection flow..."
  
  # Setup Node.js environment
  if ! setup_node_environment; then
    echo_red ">> Failed to setup Node.js environment"
    exit 1
  fi
  
  # Patch environment file
  if ! patch_env_file; then
    echo_red ">> Failed to patch .env file"
    exit 1
  fi
  
  # Start modal server
  if ! start_modal_server; then
    echo_red ">> Failed to start modal server"
    exit 1
  fi
  
  # Try to copy existing credentials first
  if copy_existing_credentials; then
    echo_green ">> Using existing credentials, skipping login..."
  else
    echo_green ">> No existing credentials found, starting login flow..."
    
    # Start localtunnel if not in Docker
    if [ -z "$DOCKER" ]; then
      if install_localtunnel && start_localtunnel; then
        echo_green ">> Localtunnel started successfully"
      else
        echo ">> Falling back to local access..."
        if command -v xdg-open >/dev/null 2>&1; then
          xdg-open http://localhost:3000 >/dev/null 2>&1 || true
        elif command -v open >/dev/null 2>&1; then
          open http://localhost:3000 2>/dev/null || true
        else
          echo ">> Please open http://localhost:3000 manually in your browser."
        fi
      fi
    else
      echo_green ">> In Docker: open http://localhost:3000 from host browser."
    fi

    echo_green ">> Waiting for login to complete..."
    local login_timeout=600  # 10 minutes
    local login_start=$(date +%s)
    
    while true; do
      if [ -f "$ROOT/modal-login/temp-data/userData.json" ] && [ -f "$ROOT/modal-login/temp-data/userApiKey.json" ]; then
        echo_green ">> Login credentials generated successfully"
        break
      fi
      
      local current_time=$(date +%s)
      if (( current_time - login_start > login_timeout )); then
        echo_red ">> ERROR: Login timeout after $login_timeout seconds"
        exit 1
      fi
      
      echo ">> Waiting for credentials... ($((current_time - login_start))s elapsed)"
      sleep 10
    done
  fi

  # Extract ORG_ID
  if ! extract_org_id; then
    echo_red ">> Failed to extract ORG_ID"
    exit 1
  fi

  # Wait for API key activation
  if ! wait_for_api_key_activation "$ORG_ID"; then
    echo_red ">> API key activation failed"
    exit 1
  fi

  cd "$ROOT"
fi

# ============================
# Python deps (CPU/GPU-aware) - FIXED
# ============================
echo_green ">> Installing Python dependencies..."
python3 -m pip install --upgrade pip

# Remove potentially conflicting versions
python3 -m pip uninstall -y torch transformers >/dev/null 2>&1 || true

# Torch installation with better error handling
install_torch() {
  local TORCH_CHANNEL_CPU="https://download.pytorch.org/whl/cpu"
  local TORCH_CUDA_CHANNEL="${TORCH_CUDA_CHANNEL:-cu121}"
  
  echo_green ">> Installing PyTorch..."
  
  if [ -n "${CPU_ONLY:-}" ]; then
    echo ">> CPU-only mode requested"
    if ! python3 -m pip install --index-url "$TORCH_CHANNEL_CPU" torch > "$ROOT/logs/pip_torch.log" 2>&1; then
      echo_red ">> CPU torch installation failed"
      return 1
    fi
  else
    if command -v nvidia-smi >/dev/null 2>&1 && [ -n "$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1)" ]; then
      echo ">> GPU detected, installing CUDA version"
      if ! python3 -m pip install --index-url "https://download.pytorch.org/whl/${TORCH_CUDA_CHANNEL}" torch > "$ROOT/logs/pip_torch.log" 2>&1; then
        echo_red ">> CUDA torch failed, falling back to CPU"
        if ! python3 -m pip install --index-url "$TORCH_CHANNEL_CPU" torch >> "$ROOT/logs/pip_torch.log" 2>&1; then
          echo_red ">> CPU torch installation also failed"
          return 1
        fi
      fi
    else
      echo ">> No GPU detected, installing CPU version"
      if ! python3 -m pip install --index-url "$TORCH_CHANNEL_CPU" torch > "$ROOT/logs/pip_torch.log" 2>&1; then
        echo_red ">> CPU torch installation failed"
        return 1
      fi
    fi
  fi
  echo_green ">> PyTorch installed successfully"
  return 0
}

# Install core packages
install_core_packages() {
  echo_green ">> Installing GenRL ${GENRL_TAG} and dependencies..."
  
  local packages=(
    "gensyn-genrl==${GENRL_TAG}"
    "trl"
    "reasoning-gym>=0.1.20"
    "hivemind@git+https://github.com/gensyn-ai/hivemind@639c964a8019de63135a2594663b5bec8e5356dd"
  )
  
  for package in "${packages[@]}"; do
    echo ">> Installing $package..."
    if ! python3 -m pip install "$package" > "$ROOT/logs/pip_${package%%[=@]*}.log" 2>&1; then
      echo_red ">> Failed to install $package"
      return 1
    fi
  done
  
  echo_green ">> All packages installed successfully"
  return 0
}

if ! install_torch; then
  echo_red ">> Torch installation failed"
  exit 1
fi

if ! install_core_packages; then
  echo_red ">> Core packages installation failed"
  exit 1
fi

# ============================
# Config sync (with reset option) - FIXED
# ============================
setup_configs() {
  if [ ! -d "$ROOT/configs" ]; then 
    mkdir -p "$ROOT/configs"
  fi
  
  local source_config="$ROOT/rgym_exp/config/rg-swarm.yaml"
  local dest_config="$ROOT/configs/rg-swarm.yaml"
  
  if [ ! -f "$source_config" ]; then
    echo_red ">> ERROR: Source config not found: $source_config"
    return 1
  fi
  
  if [ -f "$dest_config" ]; then
    if ! cmp -s "$source_config" "$dest_config"; then
      if [ -n "$GENSYN_RESET_CONFIG" ]; then
        echo_green ">> Resetting config to default as requested..."
        mv "$dest_config" "$dest_config.bak" 2>/dev/null || true
        cp "$source_config" "$dest_config"
      else
        echo_green ">> Config differences detected. Set GENSYN_RESET_CONFIG=1 to reset."
      fi
    fi
  else
    cp "$source_config" "$dest_config"
    echo_green ">> Config file created: $dest_config"
  fi
  
  if [ -n "$DOCKER" ]; then
    sudo chmod -R 0777 /home/gensyn/rl_swarm/configs 2>/dev/null || true
  fi
}

if ! setup_configs; then
  echo_red ">> Config setup failed"
  exit 1
fi

echo_green ">> Setup completed successfully!"

# ============================
# Non-interactive summaries
# ============================
echo_green ">> Configuration summary:"
echo ">> - HF Hub push: N (auto)"
echo ">> - Model: ${MODEL_NAME}"
echo ">> - PRG Game: ${PRG_GAME}"
echo_blue ">> Don't forget to star the repo: https://github.com/gensyn-ai/rl-swarm"

# ============================
# Autorestart loop + watchdog - FIXED
# ============================
stop_loop="false"
TEMP_LOG_FILE="$ROOT/logs/temp_swarm_launcher_output.log"
FINAL_LOG_FILE="$ROOT/logs/swarm_launcher.log"
PID_FILE="$ROOT/logs/gensyn_runner.pid"

LAST_ACTIVITY_TIME=$(date +%s)
STUCK_TIMEOUT_SECONDS=1200  # 20 minutes

# Activity markers
ACTIVITY_KEYWORDS=(
  "Joining round:"
  "Starting round:"
  "Map: 100%"
  "INFO] - Reasoning Gym Data Manager initialized"
  "INFO] - ✅ Connected to Gensyn Testnet"
  "INFO] - Peer ID"
  "INFO] - bootnodes:"
  "INFO] - Using Model:"
  "DHT initialized"
  "P2P daemon started"
)

ERROR_KEYWORDS=(
  "ERROR"
  "Exception occurred"
  "P2PDaemonError"
  "BlockingIOError"
  "EOFError"
  "FileNotFoundError"
  "HTTPError"
  "Resource temporarily unavailable"
  "DHTError"
  "Connection reset by peer"
)

# Function to monitor process
monitor_process() {
  local pid=$1
  local log_file=$2
  local last_activity=$(date +%s)
  local monitor_interval=15
  
  while kill -0 "$pid" 2>/dev/null; do
    sleep "$monitor_interval"
    local current_time=$(date +%s)
    
    # Check for activity in log file
    if [ -f "$log_file" ]; then
      if grep -qE "$(IFS='|'; echo "${ACTIVITY_KEYWORDS[*]}")" "$log_file"; then
        last_activity=$current_time
        echo ">> Activity detected. Resetting idle timer."
        # Clear the log after detecting activity to avoid repeated matches
        : > "$log_file"
      fi
    fi
    
    # Check for stuck process
    if (( current_time - last_activity > STUCK_TIMEOUT_SECONDS )); then
      echo_red ">> WARNING: Process appears STUCK (no activity for ${STUCK_TIMEOUT_SECONDS}s). Restarting..."
      return 1
    fi
  done
  
  return 0
}

while [ "$stop_loop" = "false" ]; do
  echo ">> Launching rgym swarm on $(date +'%Y-%m-%d %H:%M:%S')..."
  : > "$TEMP_LOG_FILE"
  : > "$PID_FILE"

  # Start the Python process
  (
    cd "$ROOT"
    CPU_ONLY="$CPU_ONLY" MODEL_NAME="$MODEL_NAME" PRG_GAME="$PRG_GAME" \
    HUGGINGFACE_ACCESS_TOKEN="$HUGGINGFACE_ACCESS_TOKEN" \
    python3 -m rgym_exp.runner.swarm_launcher \
      --config-path "$ROOT/rgym_exp/config" \
      --config-name "rg-swarm.yaml" 2>&1 &
    
    PYTHON_ACTUAL_PID=$!
    echo "$PYTHON_ACTUAL_PID" > "$PID_FILE"
    wait "$PYTHON_ACTUAL_PID"
  ) | tee "$TEMP_LOG_FILE" &
  
  TEE_PID=$!
  echo ">> Tee process PID: $TEE_PID"
  sleep 5

  # Get the Python PID
  PYTHON_ACTUAL_PID=""
  if [ -s "$PID_FILE" ]; then
    PYTHON_ACTUAL_PID=$(cat "$PID_FILE")
  fi

  if [ -z "$PYTHON_ACTUAL_PID" ] || ! kill -0 "$PYTHON_ACTUAL_PID" 2>/dev/null; then
    echo_red ">> FAILED to start Gensyn RL Swarm"
    if [ -f "$TEMP_LOG_FILE" ]; then
      ERROR_MSG=$(grep -E "$(IFS='|'; echo "${ERROR_KEYWORDS[*]}")" "$TEMP_LOG_FILE" | head -n1 || true)
      [ -n "$ERROR_MSG" ] && echo_red ">> ERROR: $ERROR_MSG"
      cat "$TEMP_LOG_FILE" >> "$FINAL_LOG_FILE"
      rm -f "$TEMP_LOG_FILE"
    fi
    echo_red ">> Restarting in 10s..."
    sleep 10
    continue
  fi

  echo_green ">> Process started successfully (PID: $PYTHON_ACTUAL_PID)"
  LAST_ACTIVITY_TIME=$(date +%s)

  # Monitor the process
  if ! monitor_process "$PYTHON_ACTUAL_PID" "$TEMP_LOG_FILE"; then
    # Process is stuck, kill it
    kill -9 "$PYTHON_ACTUAL_PID" 2>/dev/null || true
    kill -9 "$TEE_PID" 2>/dev/null || true
  fi

  # Wait for process to finish
  wait "$TEE_PID" 2>/dev/null || true

  # Append logs to final log file
  if [ -f "$TEMP_LOG_FILE" ]; then
    cat "$TEMP_LOG_FILE" >> "$FINAL_LOG_FILE"
    rm -f "$TEMP_LOG_FILE"
  fi

  # Check if we should restart
  if grep -qE "$(IFS='|'; echo "${ERROR_KEYWORDS[*]}")" "$FINAL_LOG_FILE"; then
    echo_red ">> Errors detected in logs. Restarting..."
  else
    echo_green ">> Process finished normally. Exiting."
    stop_loop="true"
  fi

  # Cleanup before restart
  cleanup
  pkill -f "DHT-" 2>/dev/null || true
  pkill -f "hivemind" 2>/dev/null || true
  
  if [ "$stop_loop" = "false" ]; then
    echo ">> Restarting in 15s..."
    sleep 15
  fi
done

echo_green ">> Gensyn RL Swarm stopped."