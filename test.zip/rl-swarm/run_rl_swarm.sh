#!/usr/bin/env bash
set -euo pipefail

# ============================
# Paths & Env
# ============================
ROOT=$PWD
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

VENV_DIR="${VENV_DIR:-$ROOT/.venv}"
VENV_BIN="$VENV_DIR/bin"
PY="$VENV_BIN/python"
PIP="$VENV_BIN/pip"

# Kontrak default (ubah jika perlu)
export SWARM_CONTRACT="${SWARM_CONTRACT:-0xFaD7C5e93f28257429569B854151A1B8DCD404c2}"
export PRG_CONTRACT="${PRG_CONTRACT:-0x51D4db531ae706a6eC732458825465058fA23a35}"

export CONNECT_TO_TESTNET=${CONNECT_TO_TESTNET:-true}
export MODEL_NAME="${MODEL_NAME:-Gensyn/Qwen2.5-1.5B-Instruct}"
export PRG_GAME="${PRG_GAME:-true}"
export HUGGINGFACE_ACCESS_TOKEN="${HUGGINGFACE_ACCESS_TOKEN:-None}"

CURL_OPTS="${CURL_OPTS:---ipv4}"
ENABLE_ULIMIT=${ENABLE_ULIMIT:-1}
GENRL_TAG="0.1.9"

SOURCE_EZLABS_DIR="/root/ezlabs/"
DEST_MODAL_DATA_DIR="$ROOT/modal-login/temp-data/"
DEST_ROOT_DIR="$ROOT/"

mkdir -p "$ROOT/logs"

GREEN="\033[32m"; RED="\033[31m"; BLUE="\033[34m"; NC="\033[0m"
logI(){ echo -e "${GREEN}$*${NC}"; }
logW(){ echo -e "${BLUE}$*${NC}"; }
logE(){ echo -e "${RED}$*${NC}"; }

# ============================
# ulimit
# ============================
if [[ "$ENABLE_ULIMIT" == "1" ]]; then
  ulimit -n 1048576 || true
  logI ">> File descriptor limit set to: $(ulimit -n)"
fi

# ============================
# Cleanup
# ============================
SERVER_PID=""
PYTHON_PID=""
TEE_PID=""

cleanup(){
  logI ">> Cleaning up..."
  pkill -f "DHT-" 2>/dev/null || true
  pkill -f "hivemind" 2>/dev/null || true
  if [[ -n "${SERVER_PID:-}" ]] && kill -0 "$SERVER_PID" 2>/dev/null; then
    kill -9 "$SERVER_PID" 2>/dev/null || true
    wait "$SERVER_PID" 2>/dev/null || true
  fi
  if [[ -n "${PYTHON_PID:-}" ]] && kill -0 "$PYTHON_PID" 2>/dev/null; then
    kill -9 "$PYTHON_PID" 2>/dev/null || true
    wait "$PYTHON_PID" 2>/dev/null || true
  fi
  if [[ -n "${TEE_PID:-}" ]] && kill -0 "$TEE_PID" 2>/dev/null; then
    kill -9 "$TEE_PID" 2>/dev/null || true
    wait "$TEE_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT

# ============================
# Helpers
# ============================
wait_port_ready(){ local h=$1 p=$2 d=$3; local end=$((SECONDS+d)); while ((SECONDS<end)); do (exec 3<>/dev/tcp/$h/$p) >/dev/null 2>&1 && return 0; sleep 1; done; return 1; }
kill_port_3000(){
  if ss -ltnp 2>/dev/null | grep -q ":3000 "; then
    logW ">> Port 3000 busy, killing listeners..."
    ss -ltnp | awk '/:3000 /{print $7}' | sed -n 's/.*pid=\([0-9]\+\).*/\1/p' | sort -u | xargs -r -n1 kill -9 || true
    sleep 1
  fi
}
http_code(){ curl -sS $CURL_OPTS -o /dev/null -w "%{http_code}" "$1" || echo "000"; }

# ============================
# Python venv & deps
# ============================
create_venv(){
  if [[ ! -x "$PY" ]]; then
    logI ">> Creating venv: $VENV_DIR"
    python3 -m venv "$VENV_DIR"
  fi
  "$PIP" install --upgrade pip
}
install_python_deps(){
  logI ">> Installing GenRL deps..."
  "$PIP" install "gensyn-genrl==${GENRL_TAG}"
  "$PIP" install "reasoning-gym>=0.1.20"
  "$PIP" install "git+https://github.com/gensyn-ai/hivemind@639c964a8019de63135a2594663b5bec8e5356dd"
  # deps untuk fallback server
  "$PIP" install fastapi uvicorn
}
reset_venv(){
  logW ">> Resetting venv..."
  rm -rf "$VENV_DIR"
  create_venv
  install_python_deps
}

create_venv
install_python_deps

# ============================
# Node & Yarn pin (via NVM)
# ============================
ensure_node(){
  export NVM_DIR="$HOME/.nvm"
  if [[ ! -s "$NVM_DIR/nvm.sh" ]]; then
    curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
  fi
  # shellcheck disable=SC1091
  . "$NVM_DIR/nvm.sh"
  nvm install 20 >/dev/null
  nvm use 20 >/dev/null
  node -v; npm -v
  if ! command -v yarn >/dev/null 2>&1; then npm i -g yarn@1 >/dev/null; fi
}
ensure_node

# ============================
# modal-login build & start
# ============================
rebuild_modal_login(){
  logW ">> Rebuilding modal-login..."
  mkdir -p "$ROOT/modal-login"
  cd "$ROOT/modal-login"
  rm -rf .next node_modules 2>/dev/null || true

  # tulis .env kontrak
  cat > .env <<ENV
SWARM_CONTRACT_ADDRESS=${SWARM_CONTRACT}
PRG_CONTRACT_ADDRESS=${PRG_CONTRACT}
NEXT_PUBLIC_SWARM_CONTRACT_ADDRESS=${SWARM_CONTRACT}
NEXT_PUBLIC_PRG_CONTRACT_ADDRESS=${PRG_CONTRACT}
ENV

  yarn install --no-progress --silent || yarn install
  # matikan telemetry (kadang bikin noise)
  npx --yes next telemetry disable || true
  NODE_ENV=production yarn build > "$ROOT/logs/yarn.log" 2>&1 || true

  if [[ ! -f ".next/BUILD_ID" ]]; then
    logE ">> Next build FAILED (no .next/BUILD_ID)."
    return 1
  fi
  cd "$ROOT"
  return 0
}

start_modal_login(){
  logI ">> Starting modal-login on 127.0.0.1:3000"
  cd "$ROOT/modal-login"
  HOSTNAME=127.0.0.1 PORT=3000 NODE_ENV=production yarn start >> "$ROOT/logs/yarn.log" 2>&1 &
  SERVER_PID=$!
  cd "$ROOT"
}

check_modal_health(){
  # tunggu port
  if ! wait_port_ready 127.0.0.1 3000 25; then
    logE ">> modal-login port 3000 not ready"
    return 1
  fi
  # /api/register-peer (boleh 200/400/405 → sehat)
  local code
  code=$(curl -sS $CURL_OPTS -o /dev/null -w "%{http_code}" -X POST "http://127.0.0.1:3000/api/register-peer" -H 'content-type: application/json' -d '{}' || echo "000")
  case "$code" in
    200|400|405) logI ">> modal-login healthy (register-peer HTTP $code)"; return 0 ;;
    *) logE ">> modal-login unhealthy (HTTP $code)"; return 2 ;;
  esac
}

ensure_modal_ready(){
  kill_port_3000
  local attempts=2 i=1
  while (( i<=attempts )); do
    logW ">> modal-login preflight attempt $i/$attempts"
    rebuild_modal_login || true
    start_modal_login
    sleep 5
    if check_modal_health; then return 0; fi

    # crash cepat? dump 30 baris terakhir
    logE ">> modal-login failed on attempt $i. Last log lines:"
    tail -n 30 "$ROOT/logs/yarn.log" || true

    if [[ -n "${SERVER_PID:-}" ]] && kill -0 "$SERVER_PID" 2>/dev/null; then
      kill -9 "$SERVER_PID" 2>/dev/null || true
      wait "$SERVER_PID" 2>/dev/null || true
      SERVER_PID=""
    fi
    ((i++))
  done
  return 1
}

# ============================
# Fallback server (FastAPI)
# ============================
write_fallback_server(){
  cat > "$ROOT/fallback_login.py" <<'PY'
import os, json
from fastapi import FastAPI, Request, Response
from fastapi.responses import PlainTextResponse, JSONResponse
app = FastAPI()

DATA_DIR = os.path.join(os.getcwd(), "modal-login", "temp-data")
os.makedirs(DATA_DIR, exist_ok=True)

def api_key_status():
    # Jika ada file userApiKey.json → anggap activated
    f = os.path.join(DATA_DIR, "userApiKey.json")
    if os.path.isfile(f):
        return "activated"
    # Atau env var override
    if os.environ.get("FORCE_ACTIVATED","0") == "1":
        return "activated"
    return "pending"

@app.post("/api/register-peer")
async def register_peer(request: Request):
    # Endpoint hanya untuk health check → 405 supaya dianggap sehat
    return Response(status_code=405)

@app.get("/api/get-api-key-status")
async def get_api_key_status(orgId: str = ""):
    return PlainTextResponse(api_key_status())

@app.get("/")
async def root():
    return JSONResponse({"ok": True, "fallback": True})

PY
}

start_fallback_server(){
  logW ">> Starting fallback login server (FastAPI) on 127.0.0.1:3000"
  "$PY" - <<'PY' &
import uvicorn, os, sys
sys.path.append(os.getcwd())
from fallback_login import app
uvicorn.run(app, host="127.0.0.1", port=3000, log_level="warning")
PY
  SERVER_PID=$!
  sleep 1
  if ! wait_port_ready 127.0.0.1 3000 10; then
    logE ">> Fallback server failed to bind port 3000"; return 1
  fi
  # sanity: register-peer should return 405
  c="$(curl -sS -o /dev/null -w '%{http_code}' -X POST http://127.0.0.1:3000/api/register-peer || echo 000)"
  [[ "$c" == "405" ]] || logW ">> Unexpected code from fallback /api/register-peer: $c"
  logI ">> Fallback server ready."
  return 0
}

# ============================
# Credentials bootstrap
# ============================
bootstrap_creds(){
  if [[ -f "$SOURCE_EZLABS_DIR/userData.json" && -f "$SOURCE_EZLABS_DIR/userApiKey.json" ]]; then
    logI ">> Found credentials in $SOURCE_EZLABS_DIR"
    mkdir -p "$DEST_MODAL_DATA_DIR"
    cp -f "$SOURCE_EZLABS_DIR/userData.json" "$DEST_MODAL_DATA_DIR"
    cp -f "$SOURCE_EZLABS_DIR/userApiKey.json" "$DEST_MODAL_DATA_DIR"
    [[ -f "$SOURCE_EZLABS_DIR/swarm.pem" && ! -f "$DEST_ROOT_DIR/swarm.pem" ]] && cp -f "$SOURCE_EZLABS_DIR/swarm.pem" "$DEST_ROOT_DIR" || true
  fi
}

# ============================
# Testnet login block
# ============================
if [[ "$CONNECT_TO_TESTNET" == true ]]; then
  echo "Please login to create an Ethereum Server Wallet"
  bootstrap_creds

  if ! ensure_modal_ready; then
    logE ">> modal-login keeps failing. Switching to fallback server."
    write_fallback_server
    start_fallback_server || { logE ">> Fallback also failed."; exit 1; }
  fi

  # ORG_ID extract (best-effort)
  ORG_ID="${ORG_ID:-}"
  if [[ -z "${ORG_ID:-}" && -f "$ROOT/modal-login/temp-data/userData.json" ]]; then
    ORG_ID="$(awk 'BEGIN{FS="\""} !/^[ \t]*[{}]/{print $(NF-1); exit}' "$ROOT/modal-login/temp-data/userData.json" || true)"
  fi
  [[ -n "${ORG_ID:-}" ]] && echo "Your ORG_ID is set to: $ORG_ID" || logW ">> ORG_ID not found (will still proceed)."

  echo "Waiting for API key to become activated..."
  # Jika fallback aktif, endpoint akan balas "activated" bila file ada / override
  while true; do
    status="$(curl -sS $CURL_OPTS "http://127.0.0.1:3000/api/get-api-key-status?orgId=${ORG_ID:-}" || echo "")"
    if [[ "$status" == "activated" ]]; then
      echo "API key is activated! Proceeding..."
      break
    fi
    sleep 5
  done
fi

# ============================
# Config sync
# ============================
mkdir -p "$ROOT/configs"
[[ -f "$ROOT/configs/rg-swarm.yaml" ]] || cp "$ROOT/rgym_exp/config/rg-swarm.yaml" "$ROOT/configs/rg-swarm.yaml"

logI ">> Setup done!"
logW ">> If modal-login crashed, fallback server is serving /api/* on port 3000."

# ============================
# Runner + Watchdog
# ============================
TEMP_LOG="$ROOT/logs/temp_swarm_launcher_output.log"
FINAL_LOG="$ROOT/logs/swarm_launcher.log"
PID_FILE="$ROOT/logs/gensyn_runner.pid"

CRITICAL="InstantiationException|register-peer|404 Client Error|ModuleNotFoundError"
ERRORS="ERROR|Exception occurred|P2PDaemonError|BlockingIOError|EOFError|FileNotFoundError|HTTPError|Resource temporarily unavailable|DHTError|Connection reset by peer"

ACTIVITIES="Joining round:|Starting round:|Map: 100%|Reasoning Gym Data Manager initialized|Connected to Gensyn Testnet|Peer ID|bootnodes:|Using Model:|DHT initialized|P2P daemon started"

STUCK=1200
while true; do
  : > "$TEMP_LOG"
  : > "$PID_FILE"
  logI ">> Launching rgym swarm..."

  (
    cd "$ROOT"
    "$PY" -m rgym_exp.runner.swarm_launcher \
      --config-path "$ROOT/rgym_exp/config" \
      --config-name "rg-swarm.yaml" 2>&1 &
    PYTHON_PID=$!
    echo "$PYTHON_PID" >&3
    wait $PYTHON_PID
    exit $?
  ) 3> "$PID_FILE" | tee "$TEMP_LOG" &

  TEE_PID=$!
  sleep 2
  # PID assurance
  for _ in {1..10}; do
    [[ -s "$PID_FILE" ]] && PYTHON_PID="$(cat "$PID_FILE")" || true
    [[ -n "${PYTHON_PID:-}" && -e "/proc/$PYTHON_PID" ]] && break
    sleep 1
  done

  if [[ -z "${PYTHON_PID:-}" || ! -e "/proc/$PYTHON_PID" ]]; then
    logE ">> Python failed to start."
    cat "$TEMP_LOG" >> "$FINAL_LOG" || true
    [[ -n "${TEE_PID:-}" ]] && kill -9 "$TEE_PID" 2>/dev/null || true
    if grep -Eq "$CRITICAL" "$FINAL_LOG" 2>/dev/null; then
      reset_venv
      ensure_modal_ready || start_fallback_server || true
    fi
    sleep 8
    continue
  fi

  last_activity=$(date +%s)
  while kill -0 "$PYTHON_PID" 2>/dev/null; do
    if grep -Eq "$ACTIVITIES" "$TEMP_LOG"; then
      : > "$TEMP_LOG"
      last_activity=$(date +%s)
    fi
    if (( $(date +%s) - last_activity > STUCK )); then
      logE ">> STUCK > ${STUCK}s, restarting..."
      kill "$PYTHON_PID" 2>/dev/null || true
      sleep 5
      kill -9 "$PYTHON_PID" 2>/dev/null || true
      break
    fi
    sleep 15
  done

  [[ -f "$TEMP_LOG" ]] && { cat "$TEMP_LOG" >> "$FINAL_LOG"; rm -f "$TEMP_LOG"; }
  [[ -n "${TEE_PID:-}" ]] && { kill -9 "$TEE_PID" 2>/dev/null || true; wait "$TEE_PID" 2>/dev/null || true; }

  if grep -Eq "$CRITICAL" "$FINAL_LOG" 2>/dev/null; then
    logE ">> Critical error detected. Resetting venv & repairing login..."
    reset_venv
    ensure_modal_ready || start_fallback_server || true
    sleep 10
    continue
  fi

  if grep -Eq "$ERRORS" "$FINAL_LOG" 2>/dev/null; then
    logW ">> Non-critical errors found. Restarting..."
    sleep 6
    continue
  fi

  logI ">> Process exited cleanly. Bye."
  break
done
