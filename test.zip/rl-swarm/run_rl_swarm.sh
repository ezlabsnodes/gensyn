#!/usr/bin/env bash
set -euo pipefail

# ============================
# General & Paths
# ============================
ROOT=$PWD
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Virtualenv (isolasi deps Python)
VENV_DIR="${VENV_DIR:-$ROOT/.venv}"
VENV_BIN="$VENV_DIR/bin"
PY="$VENV_BIN/python"
PIP="$VENV_BIN/pip"

# ============================
# Versions
# ============================
GENRL_TAG="0.1.9"

# ============================
# Environment
# ============================
export IDENTITY_PATH
export GENSYN_RESET_CONFIG
export CONNECT_TO_TESTNET=${CONNECT_TO_TESTNET:-true}
export ORG_ID
export HF_HUB_DOWNLOAD_TIMEOUT=120
export SWARM_CONTRACT="${SWARM_CONTRACT:-0xFaD7C5e93f28257429569B854151A1B8DCD404c2}"
export PRG_CONTRACT="${PRG_CONTRACT:-0x51D4db531ae706a6eC732458825465058fA23a35}"

# Non-interactive defaults
export HUGGINGFACE_ACCESS_TOKEN="${HUGGINGFACE_ACCESS_TOKEN:-None}"
export MODEL_NAME="${MODEL_NAME:-Gensyn/Qwen2.5-1.5B-Instruct}"
export PRG_GAME="${PRG_GAME:-true}"

# Curl paksa IPv4 (Netcup kadang rewel IPv6)
CURL_OPTS="${CURL_OPTS:---ipv4}"

# Path ke RSA key (auto-dibuat kalau belum ada)
DEFAULT_IDENTITY_PATH="$ROOT/swarm.pem"
IDENTITY_PATH=${IDENTITY_PATH:-$DEFAULT_IDENTITY_PATH}

DOCKER=${DOCKER:-""}
GENSYN_RESET_CONFIG=${GENSYN_RESET_CONFIG:-""}
CPU_ONLY=${CPU_ONLY:-""}
ORG_ID=${ORG_ID:-""}

# ============================
# Console colors
# ============================
GREEN_TEXT="\033[32m"; BLUE_TEXT="\033[34m"; RED_TEXT="\033[31m"; RESET_TEXT="\033[0m"
echo_green(){ echo -e "$GREEN_TEXT$1$RESET_TEXT"; }
echo_blue(){ echo -e "$BLUE_TEXT$1$RESET_TEXT"; }
echo_red(){ echo -e "$RED_TEXT$1$RESET_TEXT"; }

# ============================
# System tuning (toggleable)
# ============================
ENABLE_ULIMIT=${ENABLE_ULIMIT:-1}
if [[ "$ENABLE_ULIMIT" == "1" ]]; then
  current=$(ulimit -n || echo 1024)
  if [ "$current" -lt 65535 ]; then ulimit -n 65535 || true; fi
  echo_green ">> File descriptor limit set to: $(ulimit -n)"
else
  echo_green ">> File descriptor tuning disabled (ENABLE_ULIMIT=0). Current nofile: $(ulimit -n)"
fi

# ============================
# Auto-login helpers & state
# ============================
SOURCE_EZLABS_DIR="/root/ezlabs/"
DEST_MODAL_DATA_DIR="$ROOT/modal-login/temp-data/"
DEST_ROOT_DIR="$ROOT/"

# PIDs tracked for cleanup
SERVER_PID=""       # yarn start (modal-login)
PYTHON_ACTUAL_PID=""
TEE_PID=""
TUNNEL_PID=""

# ============================
# Cleanup & error traps
# ============================
cleanup() {
  echo_green ">> Shutting down trainer & cleaning up..."
  cd "$ROOT" || true

  pkill -f "DHT-" 2>/dev/null || true
  pkill -f "hivemind" 2>/dev/null || true
  pkill -f "lt --port" 2>/dev/null || true

  if [ -n "${SERVER_PID:-}" ] && kill -0 "$SERVER_PID" 2>/dev/null; then
    echo ">> Stopping modal-login server (PID: $SERVER_PID)..."
    kill -9 "$SERVER_PID" 2>/dev/null || true
    wait "$SERVER_PID" 2>/dev/null || true
  fi
  if [ -n "${PYTHON_ACTUAL_PID:-}" ] && kill -0 "$PYTHON_ACTUAL_PID" 2>/dev/null; then
    echo ">> Stopping Python process (PID: $PYTHON_ACTUAL_PID)..."
    kill -9 "$PYTHON_ACTUAL_PID" 2>/dev/null || true
    wait "$PYTHON_ACTUAL_PID" 2>/dev/null || true
  fi
  if [ -n "${TEE_PID:-}" ] && kill -0 "$TEE_PID" 2>/dev/null; then
    echo ">> Stopping tee (PID: $TEE_PID)..."
    kill -9 "$TEE_PID" 2>/dev/null || true
    wait "$TEE_PID" 2>/dev/null || true
  fi

  # hapus credential json (swarm.pem disimpan)
  rm -f "$ROOT_DIR/modal-login/temp-data/"*.json 2>/dev/null || true

  echo_green ">> Cleanup complete."
}

errnotify(){ echo_red ">> A critical error occurred. See $ROOT/logs for details."; }
trap cleanup EXIT
trap errnotify ERR

# ============================
# Banner
# ============================
cat << 'EOF'
\033[38;5;224m
    ██████  ██            ███████ ██     ██  █████  ██████  ███    ███
    ██   ██ ██            ██      ██     ██ ██   ██ ██   ██ ████  ████
    ██████  ██      █████ ███████ ██  █  ██ ███████ ██████  ██ ████ ██
    ██   ██ ██                 ██ ██ ███ ██ ██   ██ ██   ██ ██  ██  ██
    ██   ██ ███████       ███████  ███ ███  ██   ██ ██   ██ ██      ██

    From Gensyn
\033[0m
EOF

# ============================
# Docker perms & logs
# ============================
if [ -n "$DOCKER" ]; then
  volumes=(
    /home/gensyn/rl_swarm/modal-login/temp-data
    /home/gensyn/rl_swarm/keys
    /home/gensyn/rl_swarm/configs
    /home/gensyn/rl_swarm/logs
  )
  for volume in "${volumes[@]}"; do sudo chown -R 1001:1001 "$volume" || true; done
fi
mkdir -p "$ROOT/logs"

# ============================
# Helpers
# ============================
wait_port_ready() { # host port timeout(s)
  local host="$1" port="$2" deadline=$((SECONDS + ${3:-60}))
  while (( SECONDS < deadline )); do
    (exec 3<>/dev/tcp/"$host"/"$port") >/dev/null 2>&1 && return 0
    sleep 1
  done
  return 1
}

kill_local_port_3000_if_busy() {
  if ss -ltnp 2>/dev/null | grep -q ":3000 "; then
    echo_red ">> Port 3000 already in use. Killing local listeners..."
    pids=$(ss -ltnp 2>/dev/null | awk '/:3000 /{print $7}' | sed -n 's/.*pid=\([0-9]\+\).*/\1/p' | sort -u)
    for p in $pids; do kill -9 "$p" 2>/dev/null || true; done
    sleep 1
  fi
}

check_modal_health(){
  # 1) port ready
  wait_port_ready 127.0.0.1 3000 60 || { echo_red ">> modal-login port 3000 not ready"; return 1; }
  # 2) /api/health (opsional, ignore error)
  curl -s $CURL_OPTS "http://127.0.0.1:3000/api/health" >/dev/null || true
  # 3) route existence: /api/register-peer should NOT be 404
  code=$(curl -s $CURL_OPTS -o /dev/null -w "%{http_code}" -X POST "http://127.0.0.1:3000/api/register-peer" -H 'content-type: application/json' -d '{}'|| true)
  if [[ "$code" == "404" ]]; then
    echo_red ">> /api/register-peer returns 404 (route missing)"
    return 2
  fi
  echo_green ">> modal-login healthy (register-peer HTTP $code)"
  return 0
}

rebuild_modal_login(){
  echo_red ">> Rebuilding modal-login (clean + build)..."
  cd "$ROOT/modal-login"
  rm -rf .next node_modules yarn.lock package-lock.json 2>/dev/null || true
  yarn install --immutable
  # tulis .env aman (hindari sed by line number)
  cat > .env <<'ENV'
SWARM_CONTRACT_ADDRESS=
PRG_CONTRACT_ADDRESS=
NEXT_PUBLIC_SWARM_CONTRACT_ADDRESS=
NEXT_PUBLIC_PRG_CONTRACT_ADDRESS=
ENV
  sed -i "s|^SWARM_CONTRACT_ADDRESS=.*|SWARM_CONTRACT_ADDRESS=${SWARM_CONTRACT}|" .env
  sed -i "s|^PRG_CONTRACT_ADDRESS=.*|PRG_CONTRACT_ADDRESS=${PRG_CONTRACT}|" .env
  sed -i "s|^NEXT_PUBLIC_SWARM_CONTRACT_ADDRESS=.*|NEXT_PUBLIC_SWARM_CONTRACT_ADDRESS=${SWARM_CONTRACT}|" .env
  sed -i "s|^NEXT_PUBLIC_PRG_CONTRACT_ADDRESS=.*|NEXT_PUBLIC_PRG_CONTRACT_ADDRESS=${PRG_CONTRACT}|" .env

  HOST=127.0.0.1 PORT=3000 NODE_ENV=production yarn build > "$ROOT/logs/yarn.log" 2>&1
  cd "$ROOT"
}

start_modal_login(){
  echo_green ">> Starting modal-login (IPv4 bind 127.0.0.1:3000)"
  cd "$ROOT/modal-login"
  HOST=127.0.0.1 PORT=3000 NODE_ENV=production yarn start >> "$ROOT/logs/yarn.log" 2>&1 &
  SERVER_PID=$!
  cd "$ROOT"
}

ensure_modal_ready_with_retry(){
  # coba 3 kali: start/rebuild bila perlu sampai register-peer bukan 404
  local attempts=3 i=1
  kill_local_port_3000_if_busy
  [ -z "${SERVER_PID:-}" ] || { kill -9 "$SERVER_PID" 2>/dev/null || true; SERVER_PID=""; }

  # install Node + Yarn kalau belum ada
  if ! command -v node >/dev/null 2>&1; then
    echo_blue ">> Installing Node via NVM..."
    export NVM_DIR="$HOME/.nvm"
    [ -d "$NVM_DIR" ] || curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
    [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"
    [ -s "$NVM_DIR/bash_completion" ] && . "$NVM_DIR/bash_completion"
    nvm install 20
    nvm use 20
  fi
  if ! command -v yarn >/dev/null 2>&1; then
    echo_blue ">> Installing Yarn..."
    if grep -qi "ubuntu" /etc/os-release 2>/dev/null || uname -r | grep -qi "microsoft"; then
      sudo mkdir -p /usr/share/keyrings
      curl -fsSL https://dl.yarnpkg.com/debian/pubkey.gpg | sudo gpg --dearmor -o /usr/share/keyrings/yarn-archive-keyring.gpg
      echo "deb [signed-by=/usr/share/keyrings/yarn-archive-keyring.gpg] https://dl.yarnpkg.com/debian stable main" | sudo tee /etc/apt/sources.list.d/yarn.list >/dev/null
      sudo apt update && sudo apt install -y yarn
    else
      npm install -g --silent yarn
    fi
  fi

  cd "$ROOT/modal-login"
  # Pastikan deps terpasang sebelum start pertama
  [ -d node_modules ] || yarn install --immutable
  cd "$ROOT"

  while (( i <= attempts )); do
    echo_blue ">> modal-login preflight attempt $i/$attempts"
    start_modal_login
    sleep 5
    if check_modal_health; then
      echo_green ">> modal-login is ready."
      return 0
    fi
    echo_red ">> modal-login not ready (attempt $i). Rebuild & retry..."
    [ -n "${SERVER_PID:-}" ] && { kill -9 "$SERVER_PID" 2>/dev/null || true; SERVER_PID=""; }
    rebuild_modal_login
    ((i++))
  done
  echo_red ">> modal-login failed to become healthy after $attempts attempts."
  return 1
}

# ============================
# Python venv + official deps
# ============================
create_venv(){
  if [ ! -x "$PY" ]; then
    echo_green ">> Creating virtualenv: $VENV_DIR"
    python3 -m venv "$VENV_DIR"
  fi
  "$PIP" install --upgrade pip
}

install_official_deps(){
  echo_green ">> Installing GenRL (official deps)..."
  "$PIP" install "gensyn-genrl==${GENRL_TAG}"
  "$PIP" install "reasoning-gym>=0.1.20"
  "$PIP" install "git+https://github.com/gensyn-ai/hivemind@639c964a8019de63135a2594663b5bec8e5356dd"
}

reset_venv_and_deps(){
  echo_red ">> Resetting venv due to critical error..."
  pkill -f "$VENV_DIR/bin/python" 2>/dev/null || true
  sleep 1
  rm -rf "$VENV_DIR"
  create_venv
  install_official_deps
  echo_green ">> Venv reset complete."
}

# Ensure venv + deps
create_venv
install_official_deps

# ============================
# CONNECT_TO_TESTNET (local)
# ============================
if [ "$CONNECT_TO_TESTNET" = true ]; then
  echo "Please login to create an Ethereum Server Wallet"
  # Tulis .env aman (hindari sed berdasar nomor baris)
  mkdir -p "$ROOT/modal-login"
  if [ ! -f "$ROOT/modal-login/.env" ]; then
    cat > "$ROOT/modal-login/.env" <<'ENV'
SWARM_CONTRACT_ADDRESS=
PRG_CONTRACT_ADDRESS=
NEXT_PUBLIC_SWARM_CONTRACT_ADDRESS=
NEXT_PUBLIC_PRG_CONTRACT_ADDRESS=
ENV
  fi
  sed -i "s|^SWARM_CONTRACT_ADDRESS=.*|SWARM_CONTRACT_ADDRESS=${SWARM_CONTRACT}|" "$ROOT/modal-login/.env"
  sed -i "s|^PRG_CONTRACT_ADDRESS=.*|PRG_CONTRACT_ADDRESS=${PRG_CONTRACT}|" "$ROOT/modal-login/.env"
  sed -i "s|^NEXT_PUBLIC_SWARM_CONTRACT_ADDRESS=.*|NEXT_PUBLIC_SWARM_CONTRACT_ADDRESS=${SWARM_CONTRACT}|" "$ROOT/modal-login/.env"
  sed -i "s|^NEXT_PUBLIC_PRG_CONTRACT_ADDRESS=.*|NEXT_PUBLIC_PRG_CONTRACT_ADDRESS=${PRG_CONTRACT}|" "$ROOT/modal-login/.env"

  # Start & health-check modal-login (auto rebuild kalau 404 register-peer)
  ensure_modal_ready_with_retry

  # Autologin (copy creds) bila tersedia
  if [ -f "$SOURCE_EZLABS_DIR/userData.json" ] && [ -f "$SOURCE_EZLABS_DIR/userApiKey.json" ]; then
    echo_green ">> Found credentials at $SOURCE_EZLABS_DIR, skipping manual login..."
    mkdir -p "$DEST_MODAL_DATA_DIR"
    cp -f "$SOURCE_EZLABS_DIR/userData.json" "$DEST_MODAL_DATA_DIR"
    cp -f "$SOURCE_EZLABS_DIR/userApiKey.json" "$DEST_MODAL_DATA_DIR"
    if [ -f "$SOURCE_EZLABS_DIR/swarm.pem" ] && [ ! -f "$DEST_ROOT_DIR/swarm.pem" ]; then
      echo ">> Copying swarm.pem to project root..."
      cp -f "$SOURCE_EZLABS_DIR/swarm.pem" "$DEST_ROOT_DIR" || true
    fi
  else
    echo_green ">> Waiting for login to finish & credentials to appear..."
    while true; do
      if [ -f "$ROOT/modal-login/temp-data/userData.json" ] && [ -f "$ROOT/modal-login/temp-data/userApiKey.json" ]; then
        echo_green ">> Credentials generated."
        break
      fi
      sleep 3
    done
  fi

  # Extract ORG_ID
  if [ -f "$ROOT/modal-login/temp-data/userData.json" ]; then
    ORG_ID=$(awk 'BEGIN { FS = "\"" } !/^[ \t]*[{}]/ { print $(NF - 1); exit }' "$ROOT/modal-login/temp-data/userData.json")
    echo "Your ORG_ID is set to: $ORG_ID"
  elif [ -n "${ORG_ID:-}" ]; then
    echo_green ">> ORG_ID provided via environment: $ORG_ID"
  else
    echo_red "ERROR: userData.json not found and ORG_ID not set."; exit 1
  fi

  # Tunggu API key aktif
  echo "Waiting for API key to become activated..."
  while true; do
    STATUS=$(curl -s $CURL_OPTS "http://127.0.0.1:3000/api/get-api-key-status?orgId=$ORG_ID" || true)
    if [[ "$STATUS" == "activated" ]]; then
      echo "API key is activated! Proceeding..."
      break
    fi
    sleep 5
  done
fi

# ============================
# Config sync (with reset option)
# ============================
if [ ! -d "$ROOT/configs" ]; then mkdir -p "$ROOT/configs"; fi
if [ -f "$ROOT/configs/rg-swarm.yaml" ]; then
  if ! cmp -s "$ROOT/rgym_exp/config/rg-swarm.yaml" "$ROOT/configs/rg-swarm.yaml"; then
    if [ -z "$GENSYN_RESET_CONFIG" ]; then
      echo_green ">> Found differences in rg-swarm.yaml. Set GENSYN_RESET_CONFIG to reset to default."
    else
      echo_green ">> Backing up and resetting rg-swarm.yaml to default."
      mv "$ROOT/configs/rg-swarm.yaml" "$ROOT/configs/rg-swarm.yaml.bak"
      cp "$ROOT/rgym_exp/config/rg-swarm.yaml" "$ROOT/configs/rg-swarm.yaml"
    fi
  fi
else
  cp "$ROOT/rgym_exp/config/rg-swarm.yaml" "$ROOT/configs/rg-swarm.yaml"
fi

[ -n "$DOCKER" ] && sudo chmod -R 0777 /home/gensyn/rl_swarm/configs || true

echo_green ">> Setup done!"
echo_green ">> HF push: N (auto). Model: ${MODEL_NAME}. PRG: ${PRG_GAME}"
echo_blue  ">> Star the repo → https://github.com/gensyn-ai/rl-swarm"

# ============================
# Autorestart loop + watchdog
# ============================
stop_loop="false"
TEMP_LOG_FILE="$ROOT/logs/temp_swarm_launcher_output.log"
FINAL_LOG_FILE="$ROOT/logs/swarm_launcher.log"
PID_FILE="$ROOT/logs/gensyn_runner.pid"

LAST_ACTIVITY_TIME=$(date +%s)
STUCK_TIMEOUT_SECONDS=1200  # 20 minutes

ACTIVITY_KEYWORDS=(
  "Joining round:"
  "Starting round:"
  "Map: 100%"
  "INFO] - Reasoning Gym Data Manager initialized"
  "INFO] - ✅ Connected to Gensyn Testnet"
  "INFO] - Peer ID"
  "INFO] - bootnodes:"
  "INFO] - Using Model:"
  "DHT initialized"
  "P2P daemon started"
)

ERROR_KEYWORDS=(
  "ERROR"
  "Exception occurred"
  "P2PDaemonError"
  "BlockingIOError"
  "EOFError"
  "FileNotFoundError"
  "HTTPError"
  "Resource temporarily unavailable"
  "DHTError"
  "Connection reset by peer"
)

# pattern kritikal → cleanup + venv reset + rebuild modal-login
CRITICAL_PATTERNS="InstantiationException|register-peer|404 Client Error|ModuleNotFoundError"

while [ "$stop_loop" = "false" ]; do
  echo ">> Launching rgym swarm on $(date +'%Y-%m-%d %H:%M:%S')..."
  : > "$TEMP_LOG_FILE"
  : > "$PID_FILE"

  (
    cd "$ROOT"
    CPU_ONLY="$CPU_ONLY" MODEL_NAME="$MODEL_NAME" PRG_GAME="$PRG_GAME" HUGGINGFACE_ACCESS_TOKEN="$HUGGINGFACE_ACCESS_TOKEN" \
    "$PY" -m rgym_exp.runner.swarm_launcher \
      --config-path "$ROOT/rgym_exp/config" \
      --config-name "rg-swarm.yaml" 2>&1 &

    PYTHON_ACTUAL_PID=$!
    echo "$PYTHON_ACTUAL_PID" >&3
    wait $PYTHON_ACTUAL_PID
    exit $?
  ) 3> "$PID_FILE" | tee "$TEMP_LOG_FILE" &

  TEE_PID=$!
  echo ">> Tee process PID: $TEE_PID"
  sleep 2

  PYTHON_ACTUAL_PID=""
  for _ in {1..10}; do
    if [ -s "$PID_FILE" ]; then
      PYTHON_ACTUAL_PID=$(cat "$PID_FILE")
      if [ -n "$PYTHON_ACTUAL_PID" ] && [ -e "/proc/$PYTHON_ACTUAL_PID" ]; then break; fi
    fi
    sleep 1
  done

  # ---------- FAILED TO START ----------
  if [ -z "$PYTHON_ACTUAL_PID" ] || [ ! -e "/proc/$PYTHON_ACTUAL_PID" ]; then
    echo_red ">> FAILED to start Gensyn RL Swarm (no valid Python PID)."
    NEED_CLEANUP="false"; NEED_VENV_RESET="false"; NEED_MODAL_REBUILD="false"
    if [ -f "$TEMP_LOG_FILE" ]; then
      FIRST_ERR=$(grep -E "ERROR|Exception|HTTPError|404|register-peer|InstantiationException|ModuleNotFoundError" "$TEMP_LOG_FILE" | head -n1 || true)
      [ -n "$FIRST_ERR" ] && echo_red ">> ERROR: $FIRST_ERR"
      if echo "$FIRST_ERR" | grep -Eq "$CRITICAL_PATTERNS"; then
        NEED_CLEANUP="true"; NEED_VENV_RESET="true"; NEED_MODAL_REBUILD="true"
        echo_red ">> Critical start error → cleanup + venv reset + modal-login rebuild."
      fi
      cat "$TEMP_LOG_FILE" >> "$FINAL_LOG_FILE"; rm -f "$TEMP_LOG_FILE"
    fi
    if [ -n "$TEE_PID" ] && kill -0 "$TEE_PID" 2>/dev/null; then
      kill -9 "$TEE_PID" 2>/dev/null || true; wait "$TEE_PID" 2>/dev/null || true
    fi
    if [ "$NEED_CLEANUP" = "true" ]; then cleanup; fi
    if [ "$NEED_VENV_RESET" = "true" ]; then reset_venv_and_deps; fi
    if [ "$NEED_MODAL_REBUILD" = "true" ]; then rebuild_modal_login; ensure_modal_ready_with_retry; fi
    echo_red ">> Restarting in 10s..."; sleep 10; continue
  fi

  echo ">> Monitoring Python PID: $PYTHON_ACTUAL_PID"
  LAST_ACTIVITY_TIME=$(date +%s)
  MONITOR_INTERVAL=15
  MONITOR_LOOP_STOP="false"

  while [ "$MONITOR_LOOP_STOP" = "false" ]; do
    if ! kill -0 "$PYTHON_ACTUAL_PID" 2>/dev/null; then
      echo_green ">> Python process (PID: $PYTHON_ACTUAL_PID) has exited."
      MONITOR_LOOP_STOP="true"; break
    fi

    CURRENT_TIME=$(date +%s)

    if grep -qE "$(IFS='|'; echo "${ACTIVITY_KEYWORDS[*]}")" "$TEMP_LOG_FILE"; then
      LAST_ACTIVITY_TIME=$CURRENT_TIME
      echo ">> Activity detected. Resetting idle timer."
      : > "$TEMP_LOG_FILE"
    fi

    if (( CURRENT_TIME - LAST_ACTIVITY_TIME > STUCK_TIMEOUT_SECONDS )); then
      echo_red ">> WARNING: STUCK (> ${STUCK_TIMEOUT_SECONDS}s). Forcing restart..."
      kill "$PYTHON_ACTUAL_PID" 2>/dev/null || true; sleep 5
      if kill -0 "$PYTHON_ACTUAL_PID" 2>/dev/null; then
        echo_red ">> SIGTERM ignored. Using SIGKILL..."
        kill -9 "$PYTHON_ACTUAL_PID" 2>/dev/null || true; sleep 5
      fi
      pkill -f "DHT-" 2>/dev/null || true
      if [ -n "$TEE_PID" ] && kill -0 "$TEE_PID" 2>/dev/null; then
        kill -9 "$TEE_PID" 2>/dev/null || true; wait "$TEE_PID" 2>/dev/null || true
      fi
      MONITOR_LOOP_STOP="true"; break
    fi

    sleep "$MONITOR_INTERVAL"
  done

  if [ -f "$TEMP_LOG_FILE" ]; then
    cat "$TEMP_LOG_FILE" >> "$FINAL_LOG_FILE"; rm -f "$TEMP_LOG_FILE"
  fi
  if [ -n "$TEE_PID" ]; then wait "$TEE_PID" 2>/dev/null || true; fi

  # ---------- POST-RUN DECISION ----------
  SHOULD_RESTART_AFTER_CHECK="false"; NEED_CLEANUP="false"; NEED_VENV_RESET="false"; NEED_MODAL_REBUILD="false"

  if grep -qE "$CRITICAL_PATTERNS" "$FINAL_LOG_FILE"; then
    echo_red ">> Critical error (register-peer/404/InstantiationException/ModuleNotFoundError) detected."
    SHOULD_RESTART_AFTER_CHECK="true"; NEED_CLEANUP="true"; NEED_VENV_RESET="true"; NEED_MODAL_REBUILD="true"
  elif grep -qE "$(IFS='|'; echo "${ERROR_KEYWORDS[*]}")" "$FINAL_LOG_FILE"; then
    echo_red ">> Non-critical errors detected. Restarting..."
    SHOULD_RESTART_AFTER_CHECK="true"
  elif [ "$MONITOR_LOOP_STOP" = "true" ]; then
    echo_red ">> Process exited/crashed. Restarting..."
    SHOULD_RESTART_AFTER_CHECK="true"
  else
    echo_green ">> Process finished successfully. Exiting loop."
    SHOULD_RESTART_AFTER_CHECK="false"
  fi

  if [ "$SHOULD_RESTART_AFTER_CHECK" = "true" ]; then
    [ "$NEED_CLEANUP" = "true" ] && cleanup
    [ "$NEED_VENV_RESET" = "true" ] && reset_venv_and_deps
    if [ "$NEED_MODAL_REBUILD" = "true" ]; then
      rebuild_modal_login
      ensure_modal_ready_with_retry
    fi
    pkill -f "DHT-" 2>/dev/null || true
    pkill -f "hivemind" 2>/dev/null || true
    echo ">> Restarting in 15s..."; sleep 15
  else
    stop_loop="true"
  fi
done

echo ">> Exit."
