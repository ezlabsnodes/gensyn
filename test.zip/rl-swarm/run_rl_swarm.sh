#!/usr/bin/env bash
set -euo pipefail

# ============================
# Paths
# ============================
ROOT=$PWD
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="${VENV_DIR:-$ROOT/.venv}"
VENV_BIN="$VENV_DIR/bin"
PY="$VENV_BIN/python"
PIP="$VENV_BIN/pip"

# ============================
# Versions (pinned & compatible)
# ============================
GENRL_TAG="0.1.9"
TRANSFORMERS_VERSION="${TRANSFORMERS_VERSION:-4.51.3}"   # required by genrl 0.1.9
TRL_VERSION="${TRL_VERSION:-0.10.1}"                      # compatible with TF 4.51.x
HYDRA_VERSION="${HYDRA_VERSION:-1.3.2}"

# ============================
# Env
# ============================
export CONNECT_TO_TESTNET=${CONNECT_TO_TESTNET:-true}
export HF_HUB_DOWNLOAD_TIMEOUT=120
export HUGGINGFACE_ACCESS_TOKEN="${HUGGINGFACE_ACCESS_TOKEN:-None}"
export MODEL_NAME="${MODEL_NAME:-Gensyn/Qwen2.5-0.5B-Instruct}"
export PRG_GAME="${PRG_GAME:-true}"
export SWARM_CONTRACT="${SWARM_CONTRACT:-0xFaD7C5e93f28257429569B854151A1B8DCD404c2}"
export PRG_CONTRACT="${PRG_CONTRACT:-0x51D4db531ae706a6eC732458825465058fA23a35}"

DEFAULT_IDENTITY_PATH="$ROOT/swarm.pem"
export IDENTITY_PATH="${IDENTITY_PATH:-$DEFAULT_IDENTITY_PATH}"

DOCKER=${DOCKER:-""}
CPU_ONLY=${CPU_ONLY:-""}

# ============================
# Colors
# ============================
GREEN="\033[32m"; BLUE="\033[34m"; RED="\033[31m"; RESET="\033[0m"
log(){ echo -e "$1$2$RESET"; }; ok(){ log "$GREEN" "$1"; }; info(){ log "$BLUE" "$1"; }; err(){ log "$RED" "$1"; }

# ============================
# System tuning
# ============================
if [[ "${ENABLE_ULIMIT:-1}" == "1" ]]; then
  cur=$(ulimit -n || echo 1024); if [ "$cur" -lt 65535 ]; then ulimit -n 65535 || true; fi
  ok ">> File descriptor limit: $(ulimit -n)"
fi

# ============================
# State for helpers
# ============================
SOURCE_EZLABS_DIR="/root/ezlabs/"
DEST_MODAL_DATA_DIR="$ROOT/modal-login/temp-data/"
SERVER_PID=""; PYTHON_ACTUAL_PID=""; TEE_PID=""; TUNNEL_PID=""

# ============================
# Cleanup & traps
# ============================
cleanup() {
  ok ">> Cleaning up..."
  pkill -f "DHT-" 2>/dev/null || true
  pkill -f "hivemind" 2>/dev/null || true
  pkill -f "lt --port" 2>/dev/null || true
  [ -n "${SERVER_PID:-}" ] && kill -9 "$SERVER_PID" 2>/dev/null || true
  [ -n "${PYTHON_ACTUAL_PID:-}" ] && kill -9 "$PYTHON_ACTUAL_PID" 2>/dev/null || true
  [ -n "${TEE_PID:-}" ] && kill -9 "$TEE_PID" 2>/dev/null || true
  [ -n "${TUNNEL_PID:-}" ] && kill -9 "$TUNNEL_PID" 2>/dev/null || true
  rm -f "$ROOT/modal-login/temp-data/"*.json 2>/dev/null || true
  ok ">> Cleanup complete."
}
trap cleanup EXIT

# ============================
# Banner & logs dir
# ============================
cat << 'EOF'
\033[38;5;224m
    ██████  ██            ███████ ██     ██  █████  ██████  ███    ███
    ██   ██ ██            ██      ██     ██ ██   ██ ██   ██ ████  ████
    ██████  ██      █████ ███████ ██  █  ██ ███████ ██████  ██ ████ ██
    ██   ██ ██                 ██ ██ ███ ██ ██   ██ ██   ██ ██  ██  ██
    ██   ██ ███████       ███████  ███ ███  ██   ██ ██   ██ ██      ██
    From Gensyn
\033[0m
EOF
mkdir -p "$ROOT/logs"

# ============================
# Venv helpers
# ============================
create_venv(){ ok ">> Creating venv: $VENV_DIR"; python3 -m venv "$VENV_DIR"; "$PIP" -q install --upgrade pip wheel setuptools; }

install_stack(){
  ok ">> Installing Python requirements..."
  "$PIP" -q uninstall -y transformers torch trl importlib 2>/dev/null || true

  # Torch (CPU/GPU)
  TORCH_CPU_URL="https://download.pytorch.org/whl/cpu"
  TORCH_CUDA_CHANNEL="${TORCH_CUDA_CHANNEL:-cu121}"
  ok ">> Installing PyTorch..."
  if [ -n "$CPU_ONLY" ]; then
    "$PIP" -q install --index-url "$TORCH_CPU_URL" torch
  else
    if command -v nvidia-smi >/dev/null 2>&1; then
      "$PIP" -q install --index-url "https://download.pytorch.org/whl/${TORCH_CUDA_CHANNEL}" torch || { err ">> CUDA wheel failed; using CPU wheel"; "$PIP" -q install --index-url "$TORCH_CPU_URL" torch; }
    else
      "$PIP" -q install --index-url "$TORCH_CPU_URL" torch
    fi
  fi

  # Core & config
  "$PIP" -q install "hydra-core==${HYDRA_VERSION}" "omegaconf>=2.3" psutil requests pyyaml tqdm numpy scipy

  # Project first (declare TF pin)
  "$PIP" -q install "gensyn-genrl==${GENRL_TAG}"

  # Enforce exact TF required by genrl
  "$PIP" -q install --upgrade --force-reinstall "transformers==${TRANSFORMERS_VERSION}"

  # TRL compatible with TF 4.51.x
  "$PIP" -q install "trl==${TRL_VERSION}"

  # HF ecosystem (jangan bump TF)
  "$PIP" -q install "accelerate>=0.33" "datasets>=2.19" sentencepiece "huggingface_hub>=0.23"

  # Hivemind pinned commit
  "$PIP" -q install "git+https://github.com/gensyn-ai/hivemind@639c964a8019de63135a2594663b5bec8e5356dd"

  # Re-pin transformers lagi
  "$PIP" -q install --upgrade --force-reinstall "transformers==${TRANSFORMERS_VERSION}"

  "$PIP" check
}

# --- NEW: anti-shadowing stdlib importlib ---
fix_importlib_shadow(){
  RES=$("$PY" - <<'PY'
import sys, importlib
ok = hasattr(importlib, "util")
origin = getattr(getattr(importlib, "__spec__", None), "origin", "")
print("OK" if ok and (origin == "frozen" or origin is None or "lib/python" in (origin or "")) else "SHADOW")
PY
) || { echo "PYFAIL"; }
  if [ "$RES" = "SHADOW" ]; then
    err ">> Detected third-party 'importlib' shadowing stdlib. Removing..."
    "$PIP" uninstall -y importlib || true
  fi
}

# --- Reset venv: move-and-nuke (reliable deletion) ---
reset_venv(){
  err ">> Resetting venv (move-and-nuke)..."
  pkill -f "$VENV_DIR/bin/python" 2>/dev/null || true
  pkill -f 'pip install' 2>/dev/null || true
  sleep 1
  OLD="${VENV_DIR}.old.$(date +%s)"
  if [ -d "$VENV_DIR" ]; then
    chattr -R -i "$VENV_DIR" 2>/dev/null || true
    chmod -R u+w "$VENV_DIR" 2>/dev/null || true
    mv "$VENV_DIR" "$OLD"
  fi
  create_venv
  install_stack
  fix_importlib_shadow || true
  ok ">> New venv ready."
  if [ -d "$OLD" ]; then
    ( nice -n 19 bash -c '
        pkill -f "'"$OLD"'/bin/python" 2>/dev/null || true
        fuser -km "'"$OLD"'" 2>/dev/null || true
        chattr -R -i "'"$OLD"'" 2>/dev/null || true
        chmod -R u+w "'"$OLD"'" 2>/dev/null || true
        find "'"$OLD"'" -type f -delete 2>/dev/null || true
        find "'"$OLD"'" -depth -type d -empty -delete 2>/dev/null || true
        rm -rf "'"$OLD"'"
      ' ) >/dev/null 2>&1 &
    ok ">> Old venv scheduled for background removal: $OLD"
  fi
}

# Ensure venv
if [ ! -x "$PY" ]; then create_venv; install_stack; fi

# ============================
# Preflight (heal missing modules & versions)
# ============================
preflight(){
  local missing tfv trlv
  missing=$("$PY" - <<'PY'
import importlib
mods=["hydra","omegaconf","torch","transformers","trl","hivemind"]
print(",".join([m for m in mods if importlib.util.find_spec(m) is None]))
PY
) || { err ">> Python failed to execute preflight import check."; return 1; }

  if [ -n "$missing" ]; then
    err ">> Missing: $missing"
    [[ "$missing" == *"hydra"* ]]        && "$PIP" -q install "hydra-core==${HYDRA_VERSION}" || true
    [[ "$missing" == *"omegaconf"* ]]    && "$PIP" -q install "omegaconf>=2.3" || true
    [[ "$missing" == *"torch"* ]]        && "$PIP" -q install --index-url https://download.pytorch.org/whl/cpu torch || true
    [[ "$missing" == *"transformers"* ]] && "$PIP" -q install --force-reinstall "transformers==${TRANSFORMERS_VERSION}" || true
    [[ "$missing" == *"trl"* ]]          && "$PIP" -q install "trl==${TRL_VERSION}" || true
    [[ "$missing" == *"hivemind"* ]]     && "$PIP" -q install "git+https://github.com/gensyn-ai/hivemind@639c964a8019de63135a2594663b5bec8e5356dd" || true
  fi

  tfv=$("$PY" - <<'PY' 2>/dev/null
import importlib.metadata as md
print(md.version("transformers"))
PY
)
  if [ "${tfv:-}" != "$TRANSFORMERS_VERSION" ]; then
    err ">> transformers=$tfv, expected=$TRANSFORMERS_VERSION → re-pin"
    "$PIP" -q install --upgrade --force-reinstall "transformers==${TRANSFORMERS_VERSION}" || return 2
  fi

  trlv=$("$PY" - <<'PY' 2>/dev/null
import importlib.metadata as md
print(md.version("trl"))
PY
)
  if [ "${trlv:-}" != "$TRL_VERSION" ]; then
    err ">> trl=$trlv, expected=$TRL_VERSION → re-pin"
    "$PIP" -q install --upgrade --force-reinstall "trl==${TRL_VERSION}" || return 2
  fi

  "$PIP" check || return 2
  return 0
}

# Anti-shadowing sebelum preflight
fix_importlib_shadow || true
if ! preflight; then
  err ">> Preflight failed → full venv reset"
  reset_venv
  fix_importlib_shadow || true
  preflight || { err ">> Preflight still failing after reset"; exit 1; }
fi

# ============================
# (Optional) CONNECT_TO_TESTNET — sama seperti punyamu
# ============================
if [ "$CONNECT_TO_TESTNET" = true ]; then
  echo "Please login to create an Ethereum Server Wallet"
  cd "$ROOT/modal-login"

  # Node & Yarn
  if ! command -v node >/dev/null 2>&1; then
    export NVM_DIR="$HOME/.nvm"
    [ -d "$NVM_DIR" ] || curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
    . "$NVM_DIR/nvm.sh"
    nvm install node
  fi
  command -v yarn >/dev/null 2>&1 || npm install -g --silent yarn

  # Patch contracts
  ENV_FILE="$ROOT/modal-login/.env"
  sed -i "3s/.*/SWARM_CONTRACT_ADDRESS=$SWARM_CONTRACT/" "$ENV_FILE"
  sed -i "4s/.*/PRG_CONTRACT_ADDRESS=$PRG_CONTRACT/" "$ENV_FILE"

  yarn install --immutable
  yarn build > "$ROOT/logs/yarn.log" 2>&1 || true
  yarn start >> "$ROOT/logs/yarn.log" 2>&1 & SERVER_PID=$!
  sleep 5

  # Autologin from /root/ezlabs if present
  if [ -f "$SOURCE_EZLABS_DIR/userData.json" ] && [ -f "$SOURCE_EZLABS_DIR/userApiKey.json" ]; then
    ok ">> Found credentials at $SOURCE_EZLABS_DIR"
    mkdir -p "$DEST_MODAL_DATA_DIR"
    cp -f "$SOURCE_EZLABS_DIR/userData.json" "$DEST_MODAL_DATA_DIR" || true
    cp -f "$SOURCE_EZLABS_DIR/userApiKey.json" "$DEST_MODAL_DATA_DIR" || true
    [ -f "$SOURCE_EZLABS_DIR/swarm.pem" ] && [ ! -f "$ROOT/swarm.pem" ] && cp -f "$SOURCE_EZLABS_DIR/swarm.pem" "$ROOT" || true
  else
    ok ">> Please open http://localhost:3000 and finish login"
    until [ -f "$ROOT/modal-login/temp-data/userData.json" ] && [ -f "$ROOT/modal-login/temp-data/userApiKey.json" ]; do
      echo ">> Waiting for credentials..."
      sleep 5
    done
  fi

  cd "$ROOT"
  ORG_ID=$(awk 'BEGIN{FS="\""} !/^[ \t]*[{}]/ {print $(NF-1); exit }' "$ROOT/modal-login/temp-data/userData.json")
  echo "Your ORG_ID is set to: $ORG_ID"
  echo "Waiting for API key to become activated..."
  until [[ "$(curl -s "http://localhost:3000/api/get-api-key-status?orgId=$ORG_ID" || true)" == "activated" ]]; do
    echo "Waiting for API key to be activated..."; sleep 5
  done
fi

# ============================
# Config sync
# ============================
mkdir -p "$ROOT/configs"
if [ -f "$ROOT/configs/rg-swarm.yaml" ]; then
  if ! cmp -s "$ROOT/rgym_exp/config/rg-swarm.yaml" "$ROOT/configs/rg-swarm.yaml"; then
    if [ -n "${GENSYN_RESET_CONFIG:-}" ]; then
      mv "$ROOT/configs/rg-swarm.yaml" "$ROOT/configs/rg-swarm.yaml.bak"
      cp "$ROOT/rgym_exp/config/rg-swarm.yaml" "$ROOT/configs/rg-swarm.yaml"
    else
      ok ">> Custom rg-swarm.yaml detected (keeping it)"
    fi
  fi
else
  cp "$ROOT/rgym_exp/config/rg-swarm.yaml" "$ROOT/configs/rg-swarm.yaml"
fi

ok ">> Setup done!"
ok ">> Would you like to push models to HF Hub? [y/N]  --> N (auto)"
ok ">> Model name (repo/name) or default:  --> ${MODEL_NAME} (auto)"
ok ">> Playing PRG game: ${PRG_GAME}"
info ">> https://github.com/gensyn-ai/rl-swarm"

# ============================
# Autorestart loop + watchdog
# ============================
stop_loop="false"
TEMP_LOG="$ROOT/logs/temp_swarm_launcher_output.log"
FINAL_LOG="$ROOT/logs/swarm_launcher.log"
PID_FILE="$ROOT/logs/gensyn_runner.pid"
LAST_ACTIVITY=$(date +%s)
STUCK_TIMEOUT=1200
ACTIVITY=("Joining round:" "Starting round:" "Map: 100%" "Reasoning Gym Data Manager initialized" "✅ Connected to Gensyn Testnet" "Peer ID" "bootnodes:" "Using Model:" "DHT initialized" "P2P daemon started")
ERRORS=("ERROR" "Exception occurred" "P2PDaemonError" "BlockingIOError" "EOFError" "FileNotFoundError" "HTTPError" "Resource temporarily unavailable" "DHTError" "Connection reset by peer")
CRITICAL="InstantiationException|register-peer|404 Client Error|ModuleNotFoundError|requires transformers==${TRANSFORMERS_VERSION}"

while [ "$stop_loop" = "false" ]; do
  echo ">> Launching rgym swarm on $(date +'%Y-%m-%d %H:%M:%S')..."
  : > "$TEMP_LOG"; : > "$PID_FILE"

  (
    cd "$ROOT"
    CPU_ONLY="$CPU_ONLY" MODEL_NAME="$MODEL_NAME" PRG_GAME="$PRG_GAME" HUGGINGFACE_ACCESS_TOKEN="$HUGGINGFACE_ACCESS_TOKEN" \
    "$PY" -m rgym_exp.runner.swarm_launcher \
      --config-path "$ROOT/rgym_exp/config" \
      --config-name "rg-swarm.yaml" 2>&1 &

    PYTHON_ACTUAL_PID=$!
    echo "$PYTHON_ACTUAL_PID" >&3
    wait $PYTHON_ACTUAL_PID
    exit $?
  ) 3> "$PID_FILE" | tee "$TEMP_LOG" &

  TEE_PID=$!; sleep 2

  PYTHON_ACTUAL_PID=""
  for _ in {1..10}; do
    if [ -s "$PID_FILE" ]; then
      PYTHON_ACTUAL_PID=$(cat "$PID_FILE")
      [ -n "$PYTHON_ACTUAL_PID" ] && [ -e "/proc/$PYTHON_ACTUAL_PID" ] && break
    fi
    sleep 1
  done

  if [ -z "$PYTHON_ACTUAL_PID" ] || [ ! -e "/proc/$PYTHON_ACTUAL_PID" ]; then
    err ">> FAILED to start (no valid Python PID)."
    NEED_CLEAN="false"; NEED_RESET="false"
    if [ -f "$TEMP_LOG" ]; then
      FIRST_ERR=$(grep -E "ERROR|Exception|HTTPError|404|register-peer|InstantiationException|ModuleNotFoundError|requires transformers==" "$TEMP_LOG" | head -n1 || true)
      [ -n "$FIRST_ERR" ] && err ">> ERROR: $FIRST_ERR"
      if echo "$FIRST_ERR" | grep -Eq "$CRITICAL"; then NEED_CLEAN="true"; NEED_RESET="true"; fi
      cat "$TEMP_LOG" >> "$FINAL_LOG"; rm -f "$TEMP_LOG"
    fi
    [ -n "$TEE_PID" ] && kill -0 "$TEE_PID" 2>/dev/null && { kill -9 "$TEE_PID" 2>/dev/null || true; wait "$TEE_PID" 2>/dev/null || true; }
    [ "$NEED_CLEAN" = "true" ] && cleanup
    if [ "$NEED_RESET" = "true" ]; then reset_venv; fix_importlib_shadow || true; preflight || { err ">> Preflight still failing after reset"; exit 1; }; fi
    err ">> Restarting in 10s..."; sleep 10; continue
  fi

  echo ">> Monitoring PID: $PYTHON_ACTUAL_PID"
  LAST_ACTIVITY=$(date +%s); MONITOR=15; STOP="false"

  while [ "$STOP" = "false" ]; do
    kill -0 "$PYTHON_ACTUAL_PID" 2>/dev/null || { ok ">> Python exited."; STOP="true"; break; }
    NOW=$(date +%s)
    if grep -qE "$(IFS='|'; echo "${ACTIVITY[*]}")" "$TEMP_LOG"; then LAST_ACTIVITY=$NOW; echo ">> Activity detected"; : > "$TEMP_LOG"; fi
    if (( NOW - LAST_ACTIVITY > STUCK_TIMEOUT )); then
      err ">> STUCK > ${STUCK_TIMEOUT}s → restart"
      kill "$PYTHON_ACTUAL_PID" 2>/dev/null || true; sleep 5
      kill -0 "$PYTHON_ACTUAL_PID" 2>/dev/null && kill -9 "$PYTHON_ACTUAL_PID" 2>/dev/null || true
      pkill -f "DHT-" 2>/dev/null || true
      [ -n "$TEE_PID" ] && kill -0 "$TEE_PID" 2>/dev/null && { kill -9 "$TEE_PID" 2>/dev/null || true; wait "$TEE_PID" 2>/dev/null || true; }
      STOP="true"
    fi
    sleep "$MONITOR"
  done

  [ -f "$TEMP_LOG" ] && { cat "$TEMP_LOG" >> "$FINAL_LOG"; rm -f "$TEMP_LOG"; }
  [ -n "$TEE_PID" ] && wait "$TEE_PID" 2>/dev/null || true

  RESTART="false"; CLEAN="false"; RESET="false"
  if grep -qE "$CRITICAL" "$FINAL_LOG"; then
    err ">> Critical error detected → cleanup + venv reset"
    RESTART="true"; CLEAN="true"; RESET="true"
  elif grep -qE "$(IFS='|'; echo "${ERRORS[*]}")" "$FINAL_LOG"; then
    err ">> Non-critical error → restart only"
    RESTART="true"
  elif [ "$STOP" = "true" ]; then
    err ">> Process crashed/exited → restart"
    RESTART="true"
  else
    ok ">> Finished successfully."
  fi

  if [ "$RESTART" = "true" ]; then
    [ "$CLEAN" = "true" ] && cleanup
    if [ "$RESET" = "true" ]; then reset_venv; fix_importlib_shadow || true; preflight || { err ">> Preflight still failing after reset"; exit 1; }; fi
    pkill -f "DHT-" 2>/dev/null || true; pkill -f "hivemind" 2>/dev/null || true
    echo ">> Restarting in 15s..."; sleep 15
  else
    stop_loop="true"
  fi
done

echo ">> Exit."
