#!/usr/bin/env bash
set -euo pipefail

# --- Cek root repo ---
if [ ! -d rgym_exp/src ]; then
  echo "Jalankan dari root repo rl-swarm (harus ada folder rgym_exp/src)."
  exit 1
fi

mkdir -p rgym_exp/src rgym_exp/conf

# ==============================
# 1) rgym_exp/src/coordinator.py
# ==============================
cat > rgym_exp/src/coordinator.py <<'PY'
from __future__ import annotations

import json
import time
import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional
import requests

log = logging.getLogger(__name__)


@dataclass
class CoordinatorConfig:
    base_url: str = "http://localhost:3000"
    register_endpoint: str = "/api/register-peer"
    health_path_candidates: tuple[str, ...] = ("/api/health", "/")
    max_retries: int = 10
    backoff_seconds: float = 2.0
    timeout_seconds: float = 5.0


class Coordinator:
    def __init__(self, cfg: CoordinatorConfig):
        self.cfg = cfg.rstrip("/") if isinstance(cfg, str) else cfg

    @property
    def base_url(self) -> str:
        if isinstance(self.cfg, str):
            return self.cfg.rstrip("/")
        return self.cfg.base_url.rstrip("/")

    def _wait_frontend_ready(self) -> None:
        """Poll beberapa endpoint sampai frontend hidup atau habis retry."""
        if isinstance(self.cfg, str):
            max_retries = 10
            backoff = 2.0
            timeout = 3.0
            healths = ("/api/health", "/")
        else:
            max_retries = self.cfg.max_retries
            backoff = self.cfg.backoff_seconds
            timeout = self.cfg.timeout_seconds
            healths = self.cfg.health_path_candidates

        last_err: Optional[Exception] = None
        for attempt in range(1, max_retries + 1):
            for path in healths:
                url = f"{self.base_url}{path}"
                try:
                    r = requests.get(url, timeout=timeout)
                    if 200 <= r.status_code < 500:
                        # kalau 200 berarti sehat,
                        # kalau 404/405 pun berarti server sudah hidup
                        log.info("Frontend responded on %s (status=%s)", url, r.status_code)
                        return
                except Exception as e:
                    last_err = e
            log.info("Frontend not ready (attempt %d/%d). Sleeping %.1fs",
                     attempt, max_retries, backoff)
            time.sleep(backoff)
        if last_err:
            raise last_err

    def _safe_post_json(self, path: str, payload: Dict[str, Any]) -> requests.Response:
        if isinstance(self.cfg, str):
            timeout = 5.0
        else:
            timeout = self.cfg.timeout_seconds

        url = f"{self.base_url}{path}"
        headers = {"content-type": "application/json"}
        return requests.post(url, headers=headers, json=payload, timeout=timeout)

    def register_peer(self, peer_id: str, address: Optional[str] = None, meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Kirim ke Next API:
        POST /api/register-peer
        { "peerId": "...", "address": "...", "meta": {...} }
        """
        if not peer_id:
            raise ValueError("peer_id kosong")

        # Pastikan frontend up dulu
        self._wait_frontend_ready()

        if isinstance(self.cfg, str):
            max_retries = 5
            backoff = 2.0
        else:
            max_retries = self.cfg.max_retries
            backoff = self.cfg.backoff_seconds

        payload = {"peerId": peer_id}
        if address:
            payload["address"] = address
        if meta:
            payload["meta"] = meta

        last_error: Optional[str] = None
        for attempt in range(1, max_retries + 1):
            try:
                resp = self._safe_post_json(self.cfg.register_endpoint if not isinstance(self.cfg, str) else "/api/register-peer", payload)
                # terima 2xx sebagai sukses
                if 200 <= resp.status_code < 300:
                    try:
                        return resp.json()
                    except json.JSONDecodeError:
                        return {"ok": True, "status": resp.status_code}

                # 405 sebelumnya karena route belum support POST.
                # Sekarang kita treat sebagai error yang bisa di-retry (frontend mungkin hot-reload).
                if resp.status_code in (405, 404, 502, 503, 504):
                    last_error = f"HTTP {resp.status_code}: {resp.text[:200]}"
                    log.warning("Register peer attempt %d/%d got %s. Retry in %.1fs",
                                attempt, max_retries, last_error, backoff)
                    time.sleep(backoff)
                    continue

                # error lain: log & hentikan
                try:
                    err_body = resp.json()
                except Exception:
                    err_body = resp.text
                raise RuntimeError(f"Register peer failed: HTTP {resp.status_code} -> {err_body}")
            except requests.RequestException as e:
                last_error = repr(e)
                log.warning("Register peer attempt %d/%d: network error %s. Retry in %.1fs",
                            attempt, max_retries, last_error, backoff)
                time.sleep(backoff)

        raise RuntimeError(f"Gagal register peer setelah {max_retries} percobaan. Last error: {last_error}")
PY
echo "✓ rgym_exp/src/coordinator.py ditulis"

# ==========================
# 2) rgym_exp/src/manager.py
# ==========================
# - Gunakan Coordinator lokal
# - Ambil config dari Hydra
cat > rgym_exp/src/manager.py <<'PY'
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional
from .coordinator import Coordinator, CoordinatorConfig

log = logging.getLogger(__name__)


@dataclass
class SwarmGameManagerConfig:
    frontend_base_url: str = "http://localhost:3000"
    register_max_retries: int = 10
    register_backoff_seconds: float = 2.0
    register_timeout_seconds: float = 5.0


class SwarmGameManager:
    def __init__(self,
                 peer_id: str,
                 cfg: SwarmGameManagerConfig | None = None,
                 register_meta: Optional[Dict[str, Any]] = None):
        self.peer_id = peer_id
        cfg = cfg or SwarmGameManagerConfig()

        coord_cfg = CoordinatorConfig(
            base_url=cfg.frontend_base_url,
            max_retries=cfg.register_max_retries,
            backoff_seconds=cfg.register_backoff_seconds,
            timeout_seconds=cfg.register_timeout_seconds,
        )
        self.coordinator = Coordinator(coord_cfg)

        log.info("🔗 Frontend base URL: %s", cfg.frontend_base_url)
        # Daftar peer ke frontend
        result = self.coordinator.register_peer(self.peer_id, meta=register_meta)
        log.info("✅ Peer registered: %s", result)
PY
echo "✓ rgym_exp/src/manager.py ditulis"

# ==================================
# 3) rgym_exp/runner/swarm_launcher.py
# ==================================
# - Integrasi Hydra config baru
cat > rgym_exp/runner/swarm_launcher.py <<'PY'
from __future__ import annotations

import logging
from dataclasses import dataclass
from omegaconf import DictConfig
import hydra

from rgym_exp.src.manager import SwarmGameManager, SwarmGameManagerConfig

log = logging.getLogger(__name__)


@dataclass
class AppConfig:
    peer_id: str
    frontend: dict
    register: dict


@hydra.main(version_base=None, config_path="../conf", config_name="config")
def main(cfg: DictConfig):
    logging.basicConfig(level=logging.INFO)

    # Ambil nilai dari Hydra
    peer_id = cfg.get("peer_id", "peer-" )
    # fallback kecil biar gak kosong
    if not peer_id or peer_id == "peer-":
        import uuid
        peer_id = f"peer-{uuid.uuid4().hex[:8]}"

    gm_cfg = SwarmGameManagerConfig(
        frontend_base_url=cfg.frontend.base_url,
        register_max_retries=cfg.register.max_retries,
        register_backoff_seconds=cfg.register.backoff_seconds,
        register_timeout_seconds=cfg.register.timeout_seconds,
    )

    # Inject meta opsional
    meta = {
        "datasets": cfg.get("datasets", []),
        "notes": "launched via swarm_launcher",
    }

    manager = SwarmGameManager(peer_id=peer_id, cfg=gm_cfg, register_meta=meta)
    log.info("SwarmGameManager started with peer_id=%s", peer_id)


if __name__ == "__main__":
    main()
PY
echo "✓ rgym_exp/runner/swarm_launcher.py ditulis"

# ======================
# 4) rgym_exp/conf/config.yaml
# ======================
cat > rgym_exp/conf/config.yaml <<'YAML'
# Hydra main config for rl-swarm launcher

peer_id: ${oc.env:PEER_ID,peer-local}

frontend:
  # bisa override dengan env FRONTEND_BASE_URL
  base_url: ${oc.env:FRONTEND_BASE_URL,http://localhost:3000}

register:
  max_retries: ${oc.env:REGISTER_MAX_RETRIES,10}
  backoff_seconds: ${oc.env:REGISTER_BACKOFF_SECONDS,2.0}
  timeout_seconds: ${oc.env:REGISTER_TIMEOUT_SECONDS,5.0}

# contoh opsional info lain
datasets: []
YAML
echo "✓ rgym_exp/conf/config.yaml ditulis"

# ======================
# 5) requirements.txt (opsional)
# ======================
if [ -f requirements.txt ]; then
  if ! grep -q '^requests' requirements.txt; then
    echo "requests>=2.31.0" >> requirements.txt
    echo "✓ requests ditambahkan ke requirements.txt"
  fi
fi

# ======================
# 6) Export env contoh
# ======================
cat > .env.rl-swarm.example <<'ENV'
# ID peer untuk pendaftaran
PEER_ID=peer-local

# Base URL frontend Next.js
FRONTEND_BASE_URL=http://localhost:3000

# Retry/timeout (opsional)
REGISTER_MAX_RETRIES=10
REGISTER_BACKOFF_SECONDS=2.0
REGISTER_TIMEOUT_SECONDS=5.0
ENV
echo "✓ .env.rl-swarm.example ditulis"

echo
echo "=== Selesai. Cara jalanin: ==="
echo "1) Pastikan frontend Next.js sudah kamu perbaiki & jalan di port 3000."
echo "2) (Opsional) export env: source .env.rl-swarm.example lalu edit nilainya sesuai kebutuhan."
echo "3) Jalankan launcher:"
echo "   python -m rgym_exp.runner.swarm_launcher"
