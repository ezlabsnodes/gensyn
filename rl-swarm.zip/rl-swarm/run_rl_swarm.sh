#!/bin/bash

# Pastikan skrip akan keluar jika ada perintah yang gagal (errexit)
# atau variabel yang belum diatur (nounset).
# pipefail memastikan kegagalan dalam pipeline akan terdeteksi.
set -euo pipefail

# --- Konfigurasi Awal ---
# Menentukan direktori root skrip dengan aman
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$SCRIPT_DIR"

# Variabel konfigurasi utama
export IDENTITY_PATH
export GENSYN_RESET_CONFIG
export CONNECT_TO_TESTNET=true
export ORG_ID
export HF_HUB_DOWNLOAD_TIMEOUT=120
export SWARM_CONTRACT="0xFaD7C5e93f28257429569B854151A1B8DCD404c2"
export HUGGINGFACE_ACCESS_TOKEN="None"
AUTO_MODEL_NAME="Gensyn/Qwen2.5-0.5B-Instruct"

# --- Konfigurasi Otomatisasi Prompt ---
SOURCE_EZLABS_DIR="/root/ezlabs/"
DEST_MODAL_DATA_DIR="$ROOT/modal-login/temp-data/"
DEST_ROOT_DIR="$ROOT/"

# --- Set System Limits & Variabel Default ---
ulimit -n 65535
echo ">> Batas file descriptor diatur ke: $(ulimit -n)"

DEFAULT_IDENTITY_PATH="$ROOT/swarm.pem"
IDENTITY_PATH=${IDENTITY_PATH:-$DEFAULT_IDENTITY_PATH}

DOCKER=${DOCKER:-""}
GENSYN_RESET_CONFIG=${GENSYN_RESET_CONFIG:-""}
CPU_ONLY=${CPU_ONLY:-""}
ORG_ID=${ORG_ID:-""}

# --- Utilitas Teks Berwarna ---
GREEN_TEXT="\033[32m"
BLUE_TEXT="\033[34m"
RED_TEXT="\033[31m"
RESET_TEXT="\033[0m"

echo_green() { echo -e "${GREEN_TEXT}$1${RESET_TEXT}"; }
echo_blue() { echo -e "${BLUE_TEXT}$1${RESET_TEXT}"; }
echo_red() { echo -e "${RED_TEXT}$1${RESET_TEXT}"; }

# --- Deklarasi Variabel PID Global ---
SERVER_PID=""
PYTHON_ACTUAL_PID=""
TEE_PID=""
TUNNEL_PID=""

# --- Fungsi Cleanup Saat Keluar ---
cleanup() {
    echo_green ">> Mematikan semua proses terkait..."
    cd "$ROOT" || true

    # Gunakan pkill untuk menghentikan proses berdasarkan nama/pola
    pkill -f "DHT-" 2>/dev/null || true
    pkill -f "hivemind" 2>/dev/null || true
    pkill -f "lt --port" 2>/dev/null || true

    # Daftar PID yang akan dihentikan secara terurut
    local pids_to_kill=("$SERVER_PID" "$PYTHON_ACTUAL_PID" "$TEE_PID" "$TUNNEL_PID")
    for pid in "${pids_to_kill[@]}"; do
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            echo ">> Menghentikan proses dengan PID: $pid..."
            # Coba hentikan secara baik-baik (SIGTERM) terlebih dahulu
            kill "$pid" 2>/dev/null
            sleep 2
            # Jika masih berjalan, paksa berhenti (SIGKILL)
            if kill -0 "$pid" 2>/dev/null; then
                echo ">> Proses $pid tidak merespon, menghentikan secara paksa (SIGKILL)..."
                kill -9 "$pid" 2>/dev/null
            fi
        fi
    done
    
    # PERBAIKAN: File credential tidak dihapus agar login bisa persisten.
    # Ini adalah perilaku yang diinginkan.
    # rm -r "$ROOT/modal-login/temp-data/"*.json 2> /dev/null || true
    
    echo_green ">> Cleanup selesai."
}

# --- Fungsi Penanganan Error ---
errnotify() {
    local exit_code=$?
    echo_red ">> TERDETEKSI ERROR KRITIS PADA BARIS ${BASH_LINENO[0]} DENGAN KODE KELUAR $exit_code. Proses dihentikan."
    # Hapus trap agar tidak memicu loop error
    trap - ERR
    cleanup
    exit "$exit_code"
}

# --- Atur Trap (Jebakan) untuk Error dan Keluar ---
trap errnotify ERR
trap cleanup EXIT

# --- Tampilan Awal ---
echo -e "\033[38;5;224m"
cat << "EOF"
    ██████  ██       ███████ ██      ██  █████  ██████  ███    ███
    ██   ██ ██       ██      ██      ██ ██   ██ ██   ██ ████  ████
    ██████  ██      █████   ███████ ██  █  ██ ███████ ██████  ██ ████ ██
    ██   ██ ██      ██      ██   ██ ██   ██  ██ ██   ██ ██  ██  ██
    ██   ██ ███████  ███████  ███ ███   ██   ██ ██   ██ ██   ██

    From Gensyn
EOF

# Buat direktori logs jika belum ada
mkdir -p "$ROOT/logs"

# --- Fungsi-fungsi Utilitas ---
install_localtunnel() {
    if command -v lt >/dev/null 2>&1; then
        echo_green ">> Localtunnel sudah terinstal."
        return 0
    fi
    echo_green ">> Menginstal localtunnel..."
    if npm install -g localtunnel; then
        echo_green ">> Localtunnel berhasil diinstal."
    else
        echo_red ">> Gagal menginstal localtunnel."
        return 1
    fi
}

start_localtunnel() {
    local port=3000
    local log_file="localtunnel_output.log"
    echo_green ">> Memulai localtunnel di port $port..."
    
    # Jalankan di background
    lt --port "$port" > "$log_file" 2>&1 &
    TUNNEL_PID=$!
    
    echo ">> Menunggu URL dari localtunnel (maksimal 20 detik)..."
    for _ in {1..10}; do
        if grep -q "your url is" "$log_file"; then
            local url
            url=$(grep -o "https://[^ ]*" "$log_file" | head -n1)
            echo_green ">> Berhasil! Silakan kunjungi website ini: ${url}"
            echo_green ">> Gunakan browser Anda untuk login."
            return 0
        fi
        sleep 2
    done

    echo_red ">> Gagal mendapatkan URL localtunnel setelah 20 detik."
    kill "$TUNNEL_PID" 2>/dev/null || true
    return 1
}

# --- Proses Login dan Persiapan Awal ---
if [[ "$CONNECT_TO_TESTNET" == "true" ]]; then
    echo ">> Memulai proses login untuk membuat Ethereum Server Wallet..."

    cd "$ROOT/modal-login"
    
    # Instal Node.js via NVM jika belum ada
    if ! command -v node > /dev/null 2>&1; then
        echo ">> Node.js tidak ditemukan. Menginstal NVM dan Node.js terbaru..."
        export NVM_DIR="$HOME/.nvm"
        if [ ! -d "$NVM_DIR" ]; then
            curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
        fi
        # Source NVM untuk sesi saat ini
        [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
        nvm install node
    else
        echo ">> Node.js sudah terinstal: $(node -v)"
    fi

    # Instal Yarn jika belum ada
    if ! command -v yarn > /dev/null 2>&1; then
        echo ">> Yarn tidak ditemukan. Memulai instalasi..."
        # Deteksi Ubuntu/WSL untuk metode instalasi yang benar
        if grep -qi "ubuntu" /etc/os-release 2> /dev/null; then
            echo ">> Terdeteksi Ubuntu. Menginstal Yarn via apt..."
            # PERBAIKAN KRITIS: Menggunakan metode modern untuk menambahkan GPG key (apt-key sudah usang)
            sudo mkdir -p /etc/apt/keyrings
            curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | sudo gpg --dearmor -o /etc/apt/keyrings/yarnkey.gpg
            echo "deb [signed-by=/etc/apt/keyrings/yarnkey.gpg] https://dl.yarnpkg.com/debian/ stable main" | sudo tee /etc/apt/sources.list.d/yarn.list
            sudo apt-get update && sudo apt-get install -y yarn
        else
            echo ">> Menginstal Yarn secara global via npm..."
            npm install -g --silent yarn
        fi
    fi

    # Update alamat smart contract di file .env
    ENV_FILE="$ROOT/modal-login/.env"
    sed -i.bak "3s/.*/SMART_CONTRACT_ADDRESS=$SWARM_CONTRACT/" "$ENV_FILE"

    # Jalankan server login
    if [ -z "$DOCKER" ]; then
        echo ">> Menginstal dependensi dan membangun server login..."
        yarn install --immutable
        yarn build > "$ROOT/logs/yarn.log" 2>&1
    fi
    yarn start >> "$ROOT/logs/yarn.log" 2>&1 &
    SERVER_PID=$!
    echo ">> Proses server login dimulai dengan PID: $SERVER_PID"
    sleep 5

    # Cek keberadaan file credential untuk melewati login
    if [ -f "$SOURCE_EZLABS_DIR/userData.json" ] && [ -f "$SOURCE_EZLABS_DIR/userApiKey.json" ]; then
        echo_green ">> File credential ditemukan di $SOURCE_EZLABS_DIR. Melewati proses login."
        mkdir -p "$DEST_MODAL_DATA_DIR"
        cp -f "$SOURCE_EZLABS_DIR/userData.json" "$DEST_MODAL_DATA_DIR"
        cp -f "$SOURCE_EZLABS_DIR/userApiKey.json" "$DEST_MODAL_DATA_DIR"
        if [ -f "$SOURCE_EZLABS_DIR/swarm.pem" ] && [ ! -f "$DEST_ROOT_DIR/swarm.pem" ]; then
             cp -f "$SOURCE_EZLABS_DIR/swarm.pem" "$DEST_ROOT_DIR"
        fi
    elif [ -f "$DEST_MODAL_DATA_DIR/userData.json" ] && [ -f "$DEST_MODAL_DATA_DIR/userApiKey.json" ]; then
        echo_green ">> File credential dari sesi sebelumnya ditemukan. Melewati proses login."
    else
        echo_green ">> Memulai proses login interaktif..."
        if [ -z "$DOCKER" ]; then
            if ! install_localtunnel || ! start_localtunnel; then
                echo_blue ">> Gagal memulai localtunnel. Harap buka http://localhost:3000 secara manual di browser Anda."
            fi
        else
            echo_blue ">> Skrip berjalan di Docker. Harap buka http://localhost:3000 di browser host Anda."
        fi

        echo_green ">> Menunggu proses login di browser selesai..."
        while true; do
            if [ -f "$DEST_MODAL_DATA_DIR/userData.json" ] && [ -f "$DEST_MODAL_DATA_DIR/userApiKey.json" ]; then
                echo_green ">> File credential berhasil dibuat."
                break
            fi
            echo ">> Menunggu... Harap selesaikan login di browser."
            sleep 10
        done
    fi

    cd "$ROOT"

    # Ambil ORG_ID dari file JSON
    if [ -f "$DEST_MODAL_DATA_DIR/userData.json" ]; then
        ORG_ID=$(grep -o '"org_id":"[^"]*"' "$DEST_MODAL_DATA_DIR/userData.json" | cut -d'"' -f4)
        if [ -z "$ORG_ID" ]; then
            echo_red "ERROR: Gagal mengekstrak ORG_ID dari userData.json."
            exit 1
        fi
        echo ">> ORG_ID Anda telah disetel ke: $ORG_ID"
    else
        echo_red "ERROR: userData.json tidak ditemukan untuk mengambil ORG_ID."
        exit 1
    fi

    echo ">> Menunggu API key diaktifkan..."
    while true; do
        STATUS=$(curl -s "http://localhost:3000/api/get-api-key-status?orgId=$ORG_ID")
        if [[ "$STATUS" == "activated" ]]; then
            echo_green ">> API key telah aktif! Melanjutkan..."
            break
        else
            echo ">> Menunggu aktivasi API key..."
            sleep 5
        fi
    done
fi

# --- Instalasi Dependensi Python ---
echo_green ">> Mempersiapkan dependensi Python..."
pip install --upgrade pip

# Penanganan konflik dependensi untuk transformers, trl, dan gensyn-genrl
echo_green ">> Menginstal PyTorch (versi CPU-only)..."
pip install torch --index-url https://download.pytorch.org/whl/cpu

echo_green ">> Menginstal dependensi Python lainnya dengan urutan yang benar..."
pip install reasoning-gym>=0.1.20
# Instal hivemind dari commit spesifik
pip install hivemind@git+https://github.com/gensyn-ai/hivemind@639c964a8019de63135a2594663b5bec8e5356dd
# Instal trl yang akan menarik versi transformers yang lebih baru
pip install trl
# Terakhir, instal gensyn-genrl. Pip akan menangani dependensi sebaik mungkin.
pip install gensyn-genrl==0.1.4

# --- Konfigurasi File YAML ---
mkdir -p "$ROOT/configs"
DEFAULT_CONFIG="$ROOT/rgym_exp/config/rg-swarm.yaml"
USER_CONFIG="$ROOT/configs/rg-swarm.yaml"
if [ -f "$USER_CONFIG" ] && ! cmp -s "$DEFAULT_CONFIG" "$USER_CONFIG"; then
    if [ -z "$GENSYN_RESET_CONFIG" ]; then
        echo_green ">> Ditemukan perbedaan pada $USER_CONFIG. Set GENSYN_RESET_CONFIG untuk mereset."
    else
        echo_green ">> Mereset konfigurasi. Mencadangkan yang lama ke $USER_CONFIG.bak"
        mv "$USER_CONFIG" "$USER_CONFIG.bak"
        cp "$DEFAULT_CONFIG" "$USER_CONFIG"
    fi
else
    cp "$DEFAULT_CONFIG" "$USER_CONFIG"
fi

if [ -n "$DOCKER" ]; then
    sudo chmod -R 0777 /home/gensyn/rl_swarm/configs
fi

# --- Persiapan Selesai, Memulai Loop Utama ---
echo_green ">> Persiapan selesai!"
echo_blue ">> Jangan lupa beri bintang repo di GitHub! --> https://github.com/gensyn-ai/rl-swarm"

export MODEL_NAME="$AUTO_MODEL_NAME"
echo_green ">> Menggunakan model: $MODEL_NAME"

TEMP_LOG_FILE="$ROOT/logs/temp_swarm_launcher_output.log"
FINAL_LOG_FILE="$ROOT/logs/swarm_launcher.log"
PID_FILE="$ROOT/logs/gensyn_runner.pid"

STUCK_TIMEOUT_SECONDS=1800 # 30 menit
ACTIVITY_KEYWORDS=("Joining round:" "Starting round:" "Map: 100%" "Reasoning Gym Data Manager initialized" "Connected to Gensyn Testnet" "Peer ID" "bootnodes:" "Using Model:" "DHT initialized" "P2P daemon started")
ERROR_KEYWORDS=("ERROR" "Exception occurred" "P2PDaemonError" "BlockingIOError" "EOFError" "FileNotFoundError" "HTTPError" "Resource temporarily unavailable" "DHTError" "Connection reset by peer")

# --- Loop Utama untuk Menjalankan dan Memantau Proses ---
while true; do
    echo ">> Memulai rgym swarm launcher pada $(date +'%Y-%m-%d %H:%M:%S')..."
    
    # Kosongkan file log temporer dan PID
    > "$TEMP_LOG_FILE"
    > "$PID_FILE"

    # Jalankan proses Python di subshell untuk menangkap PID dengan benar
    (
        cd "$ROOT"
        CPU_ONLY="$CPU_ONLY" python -m rgym_exp.runner.swarm_launcher \
            --config-path "$ROOT/rgym_exp/config" \
            --config-name "rg-swarm.yaml" &
        PYTHON_ACTUAL_PID=$!
        echo "$PYTHON_ACTUAL_PID" >&3
        wait "$PYTHON_ACTUAL_PID"
    ) 3> "$PID_FILE" | tee "$TEMP_LOG_FILE" &
    TEE_PID=$!

    # Tunggu sebentar dan pastikan PID Python berhasil didapatkan
    sleep 3
    if [ -s "$PID_FILE" ]; then
        PYTHON_ACTUAL_PID=$(cat "$PID_FILE")
    else
        echo_red ">> GAGAL memulai Gensyn RL Swarm. Tidak dapat mendapatkan PID."
        echo_red ">> Mencoba restart dalam 15 detik..."
        sleep 15
        continue # Lanjut ke iterasi loop berikutnya
    fi

    echo ">> Proses Python Gensyn (PID: $PYTHON_ACTUAL_PID) sedang dipantau."
    LAST_ACTIVITY_TIME=$(date +%s)

    # Loop pemantauan
    while kill -0 "$PYTHON_ACTUAL_PID" 2>/dev/null; do
        CURRENT_TIME=$(date +%s)
        
        # Cek aktivitas di log
        if grep -qE "$(IFS='|'; echo "${ACTIVITY_KEYWORDS[*]}")" "$TEMP_LOG_FILE"; then
            echo ">> Aktivitas terdeteksi. Mereset timer pemantauan."
            LAST_ACTIVITY_TIME=$CURRENT_TIME
            # PERBAIKAN KRITIS: Kosongkan log temporer setelah aktivitas terdeteksi
            # agar tidak terus-menerus terdeteksi sebagai aktivitas baru.
            cat "$TEMP_LOG_FILE" >> "$FINAL_LOG_FILE"
            > "$TEMP_LOG_FILE"
        fi

        # Cek jika proses macet (stuck)
        if (( CURRENT_TIME - LAST_ACTIVITY_TIME > STUCK_TIMEOUT_SECONDS )); then
            echo_red ">> PERINGATAN: Proses (PID: $PYTHON_ACTUAL_PID) macet! Tidak ada aktivitas selama $STUCK_TIMEOUT_SECONDS detik."
            echo_red ">> Memaksa restart..."
            # Kill proses utama dan tee
            kill -9 "$PYTHON_ACTUAL_PID" 2>/dev/null || true
            kill -9 "$TEE_PID" 2>/dev/null || true
            break # Keluar dari loop pemantauan untuk restart
        fi

        sleep 15
    done
    
    # Simpan sisa log
    cat "$TEMP_LOG_FILE" >> "$FINAL_LOG_FILE"

    # Proses telah berhenti, cek apakah ada error untuk menentukan apakah perlu restart
    if grep -qE "$(IFS='|'; echo "${ERROR_KEYWORDS[*]}")" "$FINAL_LOG_FILE"; then
        echo_red ">> Error terdeteksi dalam log. Membersihkan dan memulai ulang dalam 15 detik..."
        cleanup
        sleep 15
    else
        echo_green ">> Proses selesai tanpa error fatal yang terdeteksi. Skrip akan keluar."
        break # Keluar dari loop utama
    fi
done

echo ">> Skrip selesai."